#!/usr/bin/env python3
import os
import logging
import sqlite3
import json
import urllib.parse
import urllib.request
import asyncio
import time
import secrets
from compat import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup, CopyTextButton,
    TimedOut, NetworkError, ContextTypes, Application, CommandHandler,
    CallbackQueryHandler, MessageHandler, filters,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_ID = os.getenv("ADMIN_ID", "8003482231")
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "@nareshdatiaofficial")
SUPPORT_WHATSAPP = os.getenv("SUPPORT_WHATSAPP", "")  # digits only, e.g. 919876543210
REFERRAL_REWARD = 1.00
PAYMENT_API_URL = os.getenv("PAYMENT_API_URL", "")
RESELLER_API_URL = os.getenv("RESELLER_API_URL", "https://xyzcheats.com/api/reseller_v1.php")
RESELLER_API_KEY = os.getenv("RESELLER_API_KEY", "")
RESELLER_MASTER_KEY = os.getenv("RESELLER_MASTER_KEY", "")
BALA_RESELLER_PRODUCT_ID = os.getenv("BALA_RESELLER_PRODUCT_ID", "136")  # legacy env; API_PRODUCTS is authoritative
BALA_LOCAL_PRODUCT_ID = os.getenv("BALA_LOCAL_PRODUCT_ID", "12")
BALA_RESELLER_LOCAL_PRODUCT_NAME = os.getenv("BALA_RESELLER_LOCAL_PRODUCT_NAME", "BALA")
PAYMENT_API_KEY = os.getenv("PAYMENT_API_KEY", "")
PAYMENT_UPI_ID = os.getenv("PAYMENT_UPI_ID", "")

# Optional second payment gateway. Admin settings override these environment values.
CASHFREE_CLIENT_ID = os.getenv("CASHFREE_CLIENT_ID", "")
CASHFREE_CLIENT_SECRET = os.getenv("CASHFREE_CLIENT_SECRET", "")
CASHFREE_ENVIRONMENT = os.getenv("CASHFREE_ENVIRONMENT", "sandbox")
CASHFREE_API_VERSION = os.getenv("CASHFREE_API_VERSION", "2025-01-01")
CASHFREE_CUSTOMER_PHONE = os.getenv("CASHFREE_CUSTOMER_PHONE", "")
PAYMENT_GATEWAY_ACTIVE = os.getenv("PAYMENT_GATEWAY_ACTIVE", "fampay")
DB_PATH = "D1"

MAINTENANCE_DEFAULT = os.getenv("BOT_MAINTENANCE", "0") == "1"
# FAST MODE: network waits are bounded and payment checks are more responsive.

# FUTURE API PRODUCTS
# -------------------
# All configured projects use the same reseller endpoint/PID mapping.
# Credentials remain environment variables; no API secret is stored in source.
# Do not put secrets in this source file; use environment variables instead.

# naresh custom emoji IDs supplied by the owner.
# Keep these IDs exactly as provided; they are used for Telegram custom emoji.
EMOJI = {
    "header": os.getenv("EMOJI_HEADER", "6278026642287764433"),       # 🏪
    "welcome": os.getenv("EMOJI_WELCOME", "6278026642287764433"),     # 🔥
    "highlights": os.getenv("EMOJI_HIGHLIGHTS", "6280308665786311768"),# 📊
    "keys": os.getenv("EMOJI_KEYS", "6280534602540917277"),           # 🔑
    "premium": os.getenv("EMOJI_PREMIUM", "6176966310920983412"),     # 🏅
    "gift": os.getenv("EMOJI_GIFT", "6098001906959916194"),           # 🎁
    "support": os.getenv("EMOJI_SUPPORT", "6280645451351859782"),     # 💬
    "secure": os.getenv("EMOJI_SECURE", "6278076442433561332"),       # 🔐
    "balance": os.getenv("EMOJI_BALANCE", "6278090066069825382"),     # 💰
    "profile": os.getenv("EMOJI_PROFILE", "6278419936738028273"),     # 😀
    "fire": os.getenv("EMOJI_FIRE", "6278026642287764433"),           # 🔥
    "melt": os.getenv("EMOJI_MELT", "6278223759811812961"),           # 🫠
    "middle": os.getenv("EMOJI_MIDDLE", "6278397800476582146"),       # 🖕
    "store": os.getenv("EMOJI_STORE", "6093562529978522804"),         # 🛒
    "reseller": os.getenv("EMOJI_RESELLER", "5258486128742244085"),   # 🪢
    "history": os.getenv("EMOJI_HISTORY", "6280534602540917277"),     # 🔑
    "referral": os.getenv("EMOJI_REFERRAL", "6098001906959916194"),   # 🎁
    "download": os.getenv("EMOJI_DOWNLOAD", "6012363763770990258"),   # 🛒
    "back": os.getenv("EMOJI_BACK", ""),
    "verify": os.getenv("EMOJI_VERIFY", ""),
    "add_balance": os.getenv("EMOJI_ADD_BALANCE", "6278495592586944657"),
    "user_id": os.getenv("EMOJI_USER_ID", "6278040244837817404"),
    "support_button": os.getenv("EMOJI_SUPPORT_BUTTON", "6064364603565941046"),
}

# Runtime-validated custom emoji IDs. Telegram returns DOCUMENT_INVALID for stale
# or invalid IDs; keep every valid "live" custom emoji and safely fall back to
# the normal Unicode emoji only for IDs Telegram rejects.
LIVE_EMOJI = {}

async def validate_custom_emojis(bot):
    """Validate every configured custom emoji ID against Telegram before polling."""
    LIVE_EMOJI.clear()
    for name, value in EMOJI.items():
        value = str(value or "").strip()
        if not value:
            LIVE_EMOJI[name] = ""
            continue
        try:
            stickers = await bot.get_custom_emoji_stickers(custom_emoji_ids=[value])
            LIVE_EMOJI[name] = value if stickers else ""
        except Exception as exc:
            logging.warning("Custom emoji %s (%s) disabled: %s", name, value, exc)
            LIVE_EMOJI[name] = ""
    good = sum(1 for v in LIVE_EMOJI.values() if v)
    logging.info("Live custom emojis: %s/%s", good, len(LIVE_EMOJI))


def emoji_tag(name, fallback):
    """Return a Telegram custom-emoji entity when its ID is live, else Unicode."""
    eid = LIVE_EMOJI.get(name, "")
    if eid:
        return f'<tg-emoji emoji-id="{eid}">{fallback}</tg-emoji>'
    return fallback


def live_icon(name):
    """Return a validated custom emoji ID for button icons, or None."""
    eid = LIVE_EMOJI.get(name, "")
    return eid or None


class BalaServiceUnavailable(RuntimeError):
    """Raised when the BALA supplier cannot complete a live purchase.

    This is deliberately separate from a normal validation error so the bot can
    show a retry/maintenance message without charging the wallet.
    """


class BalaPurchaseError(RuntimeError):
    """Raised for a supplier response that is not a temporary outage."""


FALLBACK = {
    "store": "🛒", "profile": "👤", "balance": "💰", "history": "🔑",
    "referral": "👥", "support": "📞", "download": "📥", "back": "🔙", "verify": "➕"
}

DEFAULT_CATEGORIES = {
    "PROJECTS": [
        "BALA MOD (Main id Safe)",
        "DRIP-CLIENT APK",
        "DRIP-CLIENT PROXY",
        "PRIME HOOK APK",
        "PATO TEAM SAFE APK",
        "MIGUL IPHONE",
    ],
}

API_PRODUCTS = {
    "BALA MOD (Main id Safe)": {"pid": "136", "plans": [
        ("1 Hours", 30), ("3 Hours", 70), ("6 Hours", 120), ("12 Hours", 210),
        ("1 Day", 400), ("7 Days", 2500)]},
    "DRIP-CLIENT APK": {"pid": "62", "plans": [
        ("1 Day", 70), ("3 Days", 150), ("7 Days", 250), ("15 Days", 400), ("30 Days", 650)]},
    "DRIP-CLIENT PROXY": {"pid": "91", "plans": [
        ("1 Day", 70), ("3 Days", 150), ("7 Days", 250), ("15 Days", 400), ("30 Days", 650)]},
    "PRIME HOOK APK": {"pid": "48", "plans": [
        ("1 Day", 60), ("3 Days", 110), ("7 Days", 220), ("15 Days", 350), ("30 Days", 500)]},
    "PATO TEAM SAFE APK": {"pid": "54", "plans": [
        ("3 Days", 260), ("7 Days", 400), ("15 Days", 550)]},
    "MIGUL IPHONE": {"pid": "69", "plans": [
        ("1 Day", 400), ("7 Days", 900), ("15 Days", 1500), ("30 Days", 2300)]},
}

API_PRODUCT_ALIASES = {
    "DRIPCLIENT FF NONROOT APKMOD": "62",
    "DRIPCLIENT FF PC AIMKILL": "44",
    "DRIPCLIENT FF ROOT ANDROID": "63",
    "DRIPCLIENT PROXY FF NONROOT ANDROID": "91",
    "FLUORITE IOS FF": "58",
    "FLUORITE IOS MLBB": "84",
    "HG CHEATS FF APKMOD NONROOT+ROOT": "65",
    "IOS CLOUD CODM": "87",
    "IOS FLUORITE 8 BALL POOL": "86",
    "IOS IPHONE ALL GBOX CERTIFICATE": "85",
    "PATO TEAM FF ALL ANDROID": "54",
    "PRIME HOOK FF NONROOT ANDROID": "48",
    "RAPID CORE FF ROOT ANDROID": "130",
    "SILENT CHEAT FF NONROOT APKMOD": "127",
    "SILENT CHEAT FF ROOT ANDROID": "128",
    "MIGUL IPHONE IOS FF": "69",
}

def normalize_product_name(value):
    return " ".join(str(value or "").strip().upper().split())

def api_product_config(product_name):
    name = str(product_name or "").strip()
    try:
        con = db()
        row = con.execute("SELECT * FROM api_projects WHERE lower(name)=lower(?) AND active=1", (name,)).fetchone()
        con.close()
        if row:
            return {"pid": str(row["pid"]), "endpoint": str(row["endpoint"] or "").strip(), "api_key": str(row["api_key"] or "").strip(), "master_key": str(row["master_key"] or "").strip(), "require_android_id": bool(row["require_android_id"]), "plans": []}
    except Exception:
        logging.exception("Dynamic API project lookup failed")
    # Dynamic API Projects are database-only. Old hard-coded PIDs cannot
    # become purchasable after the admin removes their project mapping.
    return None

LOCAL_MAIN_NAME = "MAIN ID HOLOGRAM"


def fetch_api_projects():
    con=db(); rows=con.execute("SELECT id,name,pid,endpoint,api_key,master_key,require_android_id,active FROM api_projects ORDER BY id").fetchall(); con.close(); return rows

def api_project_row(project_id):
    con=db(); row=con.execute("SELECT * FROM api_projects WHERE id=?",(project_id,)).fetchone(); con.close(); return row

def api_configured_for_product(product_name):
    cfg=api_product_config(product_name)
    if not cfg: return False
    return bool(str(cfg.get("endpoint") or RESELLER_API_URL).strip() and str(cfg.get("api_key") or RESELLER_API_KEY).strip())

def ensure_api_project_products(name, project_id=None):
    """Return the single canonical customer/reseller rows for an API project.

    API projects are linked by api_project_id, not by display name. This prevents
    old duplicate rows from being shown together and makes rename/toggle/delete
    affect only the selected project.
    """
    con = db()
    try:
        con.execute("INSERT OR IGNORE INTO categories(name) VALUES(?)", ("API PROJECTS",))
        cat = con.execute("SELECT id FROM categories WHERE name=?", ("API PROJECTS",)).fetchone()
        cat_id = int(cat["id"])

        if project_id is None:
            pr = con.execute("SELECT id,active FROM api_projects WHERE lower(name)=lower(?)", (str(name).strip(),)).fetchone()
            project_id = int(pr["id"]) if pr else None
        if project_id is None:
            raise ValueError("API project mapping requires a project ID")

        project = con.execute("SELECT id,name,active FROM api_projects WHERE id=?", (int(project_id),)).fetchone()
        if not project:
            raise ValueError("API project not found")
        name = str(project["name"]).strip()
        desired_active = 1 if project["active"] else 0

        products = con.execute(
            """SELECT p.id, p.active, COUNT(pl.id) AS plan_count
                 FROM products p
                 LEFT JOIN plans pl ON pl.product_id=p.id
                WHERE p.category_id=? AND (p.api_project_id=? OR (p.api_project_id IS NULL AND lower(p.name)=lower(?)))
                GROUP BY p.id, p.active
                ORDER BY CASE WHEN p.api_project_id=? THEN 0 ELSE 1 END,
                         plan_count DESC, p.id ASC""",
            (cat_id, int(project_id), name, int(project_id)),
        ).fetchall()

        if products:
            main_id = int(products[0]["id"])
            con.execute("UPDATE products SET api_project_id=?, name=?, description=?, active=? WHERE id=?",
                        (int(project_id), name, "Admin-configured live API project", desired_active, main_id))
            for dup in products[1:]:
                dup_id = int(dup["id"])
                con.execute("UPDATE products SET active=0, api_project_id=NULL WHERE id=?", (dup_id,))
                con.execute("UPDATE plans SET active=0 WHERE product_id=?", (dup_id,))
        else:
            cur = con.execute(
                "INSERT INTO products(category_id,name,description,active,api_project_id) VALUES(?,?,?,?,?)",
                (cat_id, name, "Admin-configured live API project", desired_active, int(project_id)),
            )
            main_id = int(cur.lastrowid)

        resellers = con.execute(
            """SELECT rp.id, rp.active, COUNT(rp2.id) AS plan_count
                 FROM reseller_products rp
                 LEFT JOIN reseller_plans rp2 ON rp2.product_id=rp.id
                WHERE rp.api_project_id=? OR (rp.api_project_id IS NULL AND lower(rp.name)=lower(?))
                GROUP BY rp.id, rp.active
                ORDER BY CASE WHEN rp.api_project_id=? THEN 0 ELSE 1 END,
                         plan_count DESC, rp.id ASC""",
            (int(project_id), name, int(project_id)),
        ).fetchall()

        if resellers:
            reseller_id = int(resellers[0]["id"])
            con.execute("UPDATE reseller_products SET api_project_id=?, name=?, active=? WHERE id=?",
                        (int(project_id), name, desired_active, reseller_id))
            for dup in resellers[1:]:
                dup_id = int(dup["id"])
                con.execute("UPDATE reseller_products SET active=0, api_project_id=NULL WHERE id=?", (dup_id,))
                con.execute("UPDATE reseller_plans SET active=0 WHERE product_id=?", (dup_id,))
        else:
            cur = con.execute("INSERT INTO reseller_products(name,active,api_project_id) VALUES(?,?,?)",
                              (name, desired_active, int(project_id)))
            reseller_id = int(cur.lastrowid)

        con.commit()
        return main_id, reseller_id
    finally:
        con.close()

def b(text, data, style="primary", icon=""):
    # Use a custom emoji icon only after Telegram has validated its ID.
    # If invalid/stale, retain the Unicode emoji in the button text so the
    # button still works instead of causing BadRequest: Document_invalid.
    kw = {"text": text, "callback_data": data, "style": style}
    if icon:
        live = live_icon_by_value(icon)
        if live:
            for fallback in FALLBACK.values():
                if text.startswith(fallback):
                    text = text[len(fallback):].lstrip()
                    kw["text"] = text
                    break
            kw["icon_custom_emoji_id"] = live
    return InlineKeyboardButton(**kw)


def live_icon_by_value(icon):
    value = str(icon or "").strip()
    if not value:
        return None
    return value if value in set(LIVE_EMOJI.values()) else None


def home_text(user_id):
    return f"""{emoji_tag("header", "🏪")} NARESH RESELLER STORE

{emoji_tag("welcome", "🔥")} Welcome, NARESH OFFICIAL!

{emoji_tag("highlights", "📊")} — STORE HIGHLIGHTS — {emoji_tag("highlights", "📊")}

{emoji_tag("keys", "🔑")} Premium Game Keys
{emoji_tag("premium", "🏅")} Instant Delivery 24/7
{emoji_tag("secure", "🔐")} 100% Secure Payment
{emoji_tag("balance", "💸")} Best Prices Guaranteed
{emoji_tag("gift", "🎁")} Referral Rewards
{emoji_tag("support", "💬")} Professional Support

{emoji_tag("user_id", "👤")} User ID: {user_id}
{emoji_tag("balance", "💰")} Wallet Balance: ₹{money(get_balance(user_id))}

{emoji_tag("fire", "🔥")} Select any option below to get started!"""


def home_kb(user_id=None):
    rows = [
        [b(f"{FALLBACK['store']} Product Store", "shop", "primary", EMOJI["store"])],
        [b(f"{FALLBACK['profile']} My Profile", "profile", "success", EMOJI["profile"]),
         b(f"{FALLBACK['balance']} Add Balance", "balance", "success", EMOJI["add_balance"])],
        [b(f"{FALLBACK['history']} All History", "history", "primary", EMOJI["history"]),
         b(f"{FALLBACK['referral']} Referral", "referral", "primary", EMOJI["referral"])],
        [b(f"{FALLBACK['support']} Support", "support", "success", EMOJI["support_button"])],
    ]
    # Reseller Store removed from the home menu.
    # Telegram supports primary (blue), success (green), and danger (red) button styles.
    rows.append([b(f"{FALLBACK['download']} Download APK", "download", "success", EMOJI["download"])])
    return InlineKeyboardMarkup(rows)


from d1sqlite import db

def init_db():
    # D1 schema is applied by migrations/schema.sql.
    return None

def maintenance_enabled():
    return get_setting("maintenance", "1" if MAINTENANCE_DEFAULT else "0") == "1"


def fetch_reseller_products():
    con=db(); rows=con.execute("SELECT id,name,active FROM reseller_products ORDER BY id").fetchall(); con.close(); return rows


def fetch_reseller_plans(product_id):
    con=db(); rows=con.execute("SELECT id,title,price,stock,active FROM reseller_plans WHERE product_id=? ORDER BY id",(product_id,)).fetchall(); con.close(); return rows


def reseller_product_row(product_id):
    con=db(); row=con.execute("SELECT * FROM reseller_products WHERE id=?",(product_id,)).fetchone(); con.close(); return row


def reseller_plan_row(plan_id):
    con=db(); row=con.execute("SELECT rp.*, r.name AS product FROM reseller_plans rp JOIN reseller_products r ON r.id=rp.product_id WHERE rp.id=?",(plan_id,)).fetchone(); con.close(); return row


def is_bala_reseller_plan(row):
    """Backward-compatible name: return True for any reseller product mapped to the supplier API."""
    if not row:
        return False
    name = str(row["product"] if "product" in row.keys() else "").strip()
    return api_product_config(name) is not None


def reseller_available_keys(plan_id):
    con=db(); n=con.execute("SELECT COUNT(*) n FROM reseller_keys WHERE plan_id=? AND status='available'",(plan_id,)).fetchone()["n"]; con.close(); return int(n)


def reseller_kb():
    rows=fetch_reseller_products(); kb=[[b(f"📦 {r['name']}",f"rshopprod:{r['id']}")] for r in rows if r['active']]
    kb.append([b(f"{FALLBACK['back']} BACK","home","danger",EMOJI['back'])]); return InlineKeyboardMarkup(kb)


def reseller_plan_kb(product_id):
    rows=fetch_reseller_plans(product_id); kb=[]
    product = reseller_product_row(product_id)
    is_api = bool(product and api_product_config(str(product["name"]).strip()))
    for r in rows:
        # Every configured API project is live API-backed; local stock is not used.
        if is_api:
            kb.append([b(f"⏱️ {r['title']} • ₹{r['price']}",f"rwalletbuy:{r['id']}","primary")])
        else:
            keys=reseller_available_keys(r['id'])
            kb.append([b(f"⏱️ {r['title']} • ₹{r['price']}" if keys else f"⏱️ {r['title']} • OUT OF STOCK",f"rwalletbuy:{r['id']}","primary" if keys else "danger")])
    if not rows: kb.append([b("⚠️ No plans available","noop","danger")])
    kb.append([b(f"{FALLBACK['back']} BACK","reseller_shop","danger",EMOJI['back'])]); return InlineKeyboardMarkup(kb)


def copy_key_button(key_text):
    if CopyTextButton:
        return InlineKeyboardButton("📋 COPY KEY", copy_text=CopyTextButton(text=str(key_text)))
    return b("📋 SHOW KEY", "noop", "primary")


def save_payment_order(order_id, user_id, amount, qr_url, purpose="balance", plan_id=None, gateway=None, android_id=""):
    con = db()
    con.execute(
        """INSERT OR IGNORE INTO payment_orders
           (order_id,user_id,amount,status,qr_url,purpose,plan_id,gateway,android_id)
           VALUES(?,?,?,?,?,?,?,?,?)""",
        (order_id, user_id, amount, "pending", qr_url or "", purpose, plan_id, gateway or get_active_payment_gateway() or "fampay", android_id or ""),
    )
    con.commit()
    con.close()


def is_api_product(row):
    """True when the product has a configured supplier PID."""
    if not row:
        return False
    keys = row.keys()
    name = str(row["name"] if "name" in keys else row["product"] if "product" in keys else "").strip()
    return api_product_config(name) is not None


def available_key_count(plan_id):
    row = plan_row(plan_id)
    if row and is_api_product(row):
        return 1
    con = db()
    n = con.execute("SELECT COUNT(*) AS n FROM plan_keys WHERE plan_id=? AND status='available'", (plan_id,)).fetchone()["n"]
    con.close()
    return int(n)


def api_duration(title):
    return api_duration_variants(title)[0]


def api_duration_variants(title):
    """Preferred duration first, with a singular/plural fallback when supplier rejects price/duration."""
    t = str(title).strip().upper().replace("–", "-").replace("—", "-")
    mapping = {
        "1 HOUR": ["1 Hours", "1 Hour"], "1 HOURS": ["1 Hours", "1 Hour"],
        "3 HOUR": ["3 Hours", "3 Hour"], "3 HOURS": ["3 Hours", "3 Hour"],
        "6 HOUR": ["6 Hours", "6 Hour"], "6 HOURS": ["6 Hours", "6 Hour"],
        "12 HOUR": ["12 Hours", "12 Hour"], "12 HOURS": ["12 Hours", "12 Hour"],
        "1 DAY": ["1 Day", "1 Days", "1 day", "1 days"], "1 DAYS": ["1 Days", "1 Day", "1 days", "1 day"],
        "2 DAY": ["2 Days", "2 Day", "2 days", "2 day"], "2 DAYS": ["2 Days", "2 Day", "2 days", "2 day"],
        "3 DAY": ["3 Days", "3 Day", "3 days", "3 day"], "3 DAYS": ["3 Days", "3 Day", "3 days", "3 day"],
        "5 DAY": ["5 Days", "5 Day", "5 days", "5 day"], "5 DAYS": ["5 Days", "5 Day", "5 days", "5 day"],
        "7 DAY": ["7 Days", "7 Day", "7 days", "7 day"], "7 DAYS": ["7 Days", "7 Day", "7 days", "7 day"],
        "10 DAY": ["10 Days", "10 Day", "10 days", "10 day"], "10 DAYS": ["10 Days", "10 Day", "10 days", "10 day"],
        "14 DAY": ["14 Days", "14 Day", "14 days", "14 day"], "14 DAYS": ["14 Days", "14 Day", "14 days", "14 day"],
        "15 DAY": ["15 Days", "15 Day", "15 days", "15 day"], "15 DAYS": ["15 Days", "15 Day", "15 days", "15 day"],
        "28 DAY": ["28 Days", "28 Day", "28 days", "28 day"], "28 DAYS": ["28 Days", "28 Day", "28 days", "28 day"],
        "30 DAY": ["30 Days", "30 Day", "30 days", "30 day"], "30 DAYS": ["30 Days", "30 Day", "30 days", "30 day"],
    }
    return mapping.get(t, [str(title).strip()])


def reseller_buy_api(plan, user_id, android_id=""):
    """Buy a fresh key from an admin-configured API project or the legacy supplier mapping."""
    product_name = str(plan["product"]).strip()
    cfg = api_product_config(product_name)
    if not cfg:
        raise BalaPurchaseError(f"API mapping not found for {product_name}")
    endpoint=str(cfg.get("endpoint") or RESELLER_API_URL).strip()
    api_key=str(cfg.get("api_key") or RESELLER_API_KEY).strip()
    master_key=str(cfg.get("master_key") or RESELLER_MASTER_KEY).strip()
    if not endpoint or not api_key:
        raise BalaServiceUnavailable(f"API is not configured for {product_name}.")
    if cfg.get("require_android_id") and not str(android_id or "").strip():
        raise BalaPurchaseError("Android ID is required for this project.")

    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "x-master-key": master_key,
        "User-Agent": "NareshBot/1.0",
    }
    result = None
    http_status = 200
    custom_duration = str(plan["api_duration"] or "").strip() if "api_duration" in plan.keys() else ""
    durations = [custom_duration] if custom_duration else api_duration_variants(plan["title"])
    for index, duration in enumerate(durations):
        data = {
            "api_key": api_key,
            "action": "buy",
            "product_id": cfg["pid"],
            "duration": duration,
        }
        if str(android_id or "").strip():
            data["android_id"] = str(android_id).strip()
        req = urllib.request.Request(endpoint, data=urllib.parse.urlencode(data).encode("utf-8"), headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                http_status = getattr(resp, "status", 200)
        except Exception as exc:
            logging.exception("Reseller API request failed")
            raise BalaServiceUnavailable("Reseller API is temporarily unavailable. Your wallet was NOT charged.") from exc
        try:
            result = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise BalaServiceUnavailable("Reseller API returned an invalid response. Your wallet was NOT charged.") from exc
        nested = result.get("data") if isinstance(result, dict) and isinstance(result.get("data"), dict) else {}
        message = str((result.get("msg") if isinstance(result, dict) else "") or (result.get("message") if isinstance(result, dict) else "") or (result.get("error") if isinstance(result, dict) else "") or nested.get("msg") or nested.get("message") or nested.get("error") or "").strip()
        low = message.lower()
        duration_problem = any(x in low for x in ("price not found", "duration not found", "invalid duration", "plan not found"))
        if not duration_problem or index == len(durations) - 1:
            break

    def find_key(obj):
        if isinstance(obj, dict):
            for name in ("key", "license_key", "license", "serial", "token", "licenseKey", "license_code", "activation_key", "code"):
                value = obj.get(name)
                if isinstance(value, (str, int, float)) and str(value).strip():
                    return str(value).strip()
            for name in ("data", "result", "purchase", "order", "response", "item"):
                found = find_key(obj.get(name))
                if found:
                    return found
        elif isinstance(obj, list):
            for value in obj:
                found = find_key(value)
                if found:
                    return found
        return ""

    key = find_key(result)
    if key:
        return key

    status = str(result.get("status", "")).strip().lower() if isinstance(result, dict) else ""
    nested = result.get("data") if isinstance(result, dict) and isinstance(result.get("data"), dict) else {}
    message = ""
    if isinstance(result, dict):
        message = result.get("msg") or result.get("message") or result.get("error") or nested.get("msg") or nested.get("message") or nested.get("error") or "Key purchase failed"
    message = str(message).strip()
    temporary_words = ("maintenance", "temporarily", "try again", "server", "timeout", "timed out", "unavailable", "offline", "down", "connection", "service unavailable", "bad gateway", "gateway timeout")
    if http_status >= 500 or any(word in message.lower() for word in temporary_words):
        raise BalaServiceUnavailable("Reseller API is temporarily unavailable. Your wallet was NOT charged.")
    raise BalaPurchaseError(message or "Reseller API rejected the purchase")


def deliver_paid_plan(order_id, verify_json):
    """After payment verification, generate a fresh Reseller API key and store the delivered key."""
    if str(verify_json.get("status", "")).lower() != "success":
        return False, None

    con = db()
    try:
        con.execute("BEGIN IMMEDIATE")
        order = con.execute("SELECT * FROM payment_orders WHERE order_id=?", (order_id,)).fetchone()
        if not order or order["purpose"] != "plan":
            con.rollback()
            return False, None

        existing = con.execute("SELECT * FROM purchases WHERE order_id=?", (order_id,)).fetchone()
        if existing and existing["status"] == "delivered":
            key = existing["delivery_key"]
            if key:
                con.rollback()
                return True, key
            con.rollback()
            return False, None

        plan = con.execute(
            """SELECT pl.id,pl.title,pl.price,pl.product_id,pl.api_duration,p.name AS product
               FROM plans pl JOIN products p ON p.id=pl.product_id WHERE pl.id=?""",
            (order["plan_id"],),
        ).fetchone()
        if not plan:
            con.rollback()
            return False, None

        is_api = is_api_product(plan)
        con.commit()
    finally:
        con.close()

    if is_api:
        logging.info(
            "Reseller API delivery: order=%s plan=%s title=%s",
            order_id, order["plan_id"], plan["title"]
        )
        key_text = reseller_buy_api(plan, order["user_id"], order["android_id"] if "android_id" in order.keys() else "")
        con = db()
        try:
            con.execute("BEGIN IMMEDIATE")
            existing = con.execute("SELECT * FROM purchases WHERE order_id=?", (order_id,)).fetchone()
            if existing and existing["status"] == "delivered" and existing["delivery_key"]:
                con.rollback()
                return True, existing["delivery_key"]
            con.execute(
                """INSERT OR IGNORE INTO purchases
                   (order_id,user_id,plan_id,amount,key_id,delivery_key,delivery_source,status,delivered_at)
                   VALUES(?,?,?,?,NULL,?,?, 'delivered',CURRENT_TIMESTAMP)""",
                (order_id, order["user_id"], order["plan_id"], order["amount"], key_text, "reseller_api"),
            )
            con.execute(
                "UPDATE payment_orders SET status='success', credited_at=CURRENT_TIMESTAMP WHERE order_id=?",
                (order_id,),
            )
            con.commit()
            return True, key_text
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    # Non-BALA products keep the original local-key delivery flow.
    con = db()
    try:
        con.execute("BEGIN IMMEDIATE")
        key = con.execute(
            "SELECT * FROM plan_keys WHERE plan_id=? AND status='available' ORDER BY id LIMIT 1",
            (order["plan_id"],),
        ).fetchone()
        if not key:
            con.rollback()
            return False, None
        con.execute(
            """INSERT OR IGNORE INTO purchases
               (order_id,user_id,plan_id,amount,key_id,status,delivered_at)
               VALUES(?,?,?,?,?,'delivered',CURRENT_TIMESTAMP)""",
            (order_id, order["user_id"], order["plan_id"], order["amount"], key["id"]),
        )
        con.execute("UPDATE plan_keys SET status='sold',assigned_user_id=?,assigned_at=CURRENT_TIMESTAMP WHERE id=? AND status='available'", (order["user_id"], key["id"]))
        con.execute("UPDATE payment_orders SET status='success',credited_at=CURRENT_TIMESTAMP WHERE order_id=?", (order_id,))
        con.commit()
        return True, key["key_text"]
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

def fam_base_url():
    base = payment_setting("fampay_api_url", "PAYMENT_API_URL", PAYMENT_API_URL).strip().rstrip("/")
    for suffix in ("/qr.php", "/verify.php"):
        if base.endswith(suffix):
            base = base[:-len(suffix)]
    return base


def fam_get(path, params):
    url = fam_base_url() + path + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "NareshBot/1.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw)


def credit_order_if_paid(order_id, verify_json):
    status = str(verify_json.get("status", "")).lower()
    data = verify_json.get("data") or {}
    if status != "success":
        return False, None
    con = db()
    try:
        con.execute("BEGIN IMMEDIATE")
        order = con.execute("SELECT * FROM payment_orders WHERE order_id=?", (order_id,)).fetchone()
        if not order:
            con.rollback()
            return False, None
        if order["status"] == "success":
            bal = con.execute("SELECT balance FROM users WHERE user_id=?", (order["user_id"],)).fetchone()["balance"]
            con.rollback()
            return True, round(float(bal), 2)
        con.execute("INSERT OR IGNORE INTO users(user_id,balance) VALUES(?,0)", (order["user_id"],))
        con.execute("UPDATE users SET balance=balance+?, updated_at=CURRENT_TIMESTAMP WHERE user_id=?", (order["amount"], order["user_id"]))
        con.execute("UPDATE payment_orders SET status='success', credited_at=CURRENT_TIMESTAMP WHERE order_id=?", (order_id,))
        bal = con.execute("SELECT balance FROM users WHERE user_id=?", (order["user_id"],)).fetchone()["balance"]
        con.commit()
        return True, round(float(bal), 2)
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


async def verify_payment_loop(application, chat_id, user_id, order_id, amount):
    # Faster payment confirmation: check every 2 seconds for up to 2 minutes.
    for _ in range(60):
        try:
            con = db()
            order = con.execute("SELECT purpose, plan_id, gateway FROM payment_orders WHERE order_id=?", (order_id,)).fetchone()
            con.close()
            gateway = str(order["gateway"] if order and "gateway" in order.keys() else "fampay").lower()
            result = await asyncio.to_thread(verify_gateway_payment, gateway, order_id)

            if order and order["purpose"] == "plan":
                delivered, key_text = await asyncio.to_thread(deliver_paid_plan, order_id, result)
                if delivered:
                    await application.bot.send_message(
                        chat_id=chat_id,
                        text=f"✅ PAYMENT VERIFIED & ORDER DELIVERED\n\n"
                             f"Amount: ₹{amount}\nOrder ID: {order_id}\n\n"
                             f"🔑 YOUR KEY:\n{key_text}\n\n"
                             f"Use the key according to the product instructions.",
                        reply_markup=home_kb(),
                    )
                    return
            else:
                paid, balance = credit_order_if_paid(order_id, result)
                if paid:
                    await application.bot.send_message(
                        chat_id=chat_id,
                        text=f"✅ PAYMENT RECEIVED\n\nAmount: ₹{amount}\nOrder ID: {order_id}\n💰 New Balance: ₹{balance}",
                        reply_markup=home_kb(),
                    )
                    return
        except Exception as exc:
            logging.warning("Payment verify failed for %s: %s", order_id, exc)
        await asyncio.sleep(2)

    await application.bot.send_message(
        chat_id=chat_id,
        text=f"⌛ PAYMENT CHECK EXPIRED\n\nOrder ID: {order_id}\nIf you already paid, tap Check Payment.",
        reply_markup=home_kb(),
    )


def seed_defaults(con):
    """Clean legacy catalogs and repair one-to-one API project mappings."""
    # Hide legacy hard-coded project catalogs. Purchase history is preserved.
    con.execute("""
        UPDATE products SET active=0
        WHERE category_id IN (
            SELECT id FROM categories WHERE upper(name) IN ('PROJECTS','API PROJECTS')
        )
    """)
    con.execute("""
        UPDATE plans SET active=0
        WHERE product_id IN (
            SELECT p.id FROM products p
            JOIN categories c ON c.id=p.category_id
            WHERE upper(c.name) IN ('PROJECTS','API PROJECTS')
        )
    """)
    con.execute("INSERT OR IGNORE INTO categories(name) VALUES('API PROJECTS')")
    cat = con.execute("SELECT id FROM categories WHERE name='API PROJECTS'").fetchone()
    cat_id = int(cat['id'])

    for project in con.execute("SELECT * FROM api_projects ORDER BY id").fetchall():
        project_id = int(project['id'])
        name = str(project['name']).strip()
        desired_active = 1 if project['active'] else 0

        products = con.execute(
            """SELECT p.id, p.active, p.category_id, COUNT(pl.id) AS plan_count
                 FROM products p
                 LEFT JOIN plans pl ON pl.product_id=p.id
                WHERE p.api_project_id=? OR (p.api_project_id IS NULL AND lower(p.name)=lower(?))
                GROUP BY p.id, p.active, p.category_id
                ORDER BY CASE WHEN p.api_project_id=? THEN 0
                              WHEN p.category_id=? THEN 1 ELSE 2 END,
                         plan_count DESC, p.id ASC""",
            (project_id, name, project_id, cat_id),
        ).fetchall()

        if products:
            main_id = int(products[0]['id'])
            con.execute("UPDATE products SET api_project_id=?, name=?, description=?, active=? WHERE id=?",
                        (project_id, name, 'Admin-configured live API project', desired_active, main_id))
            for dup in products[1:]:
                dup_id = int(dup['id'])
                con.execute("UPDATE products SET active=0, api_project_id=NULL WHERE id=?", (dup_id,))
                con.execute("UPDATE plans SET active=0 WHERE product_id=?", (dup_id,))
        else:
            main_id = int(con.execute(
                "INSERT INTO products(category_id,name,description,active,api_project_id) VALUES(?,?,?,?,?)",
                (cat_id, name, 'Admin-configured live API project', desired_active, project_id),
            ).lastrowid)

        resellers = con.execute(
            """SELECT rp.id, rp.active, COUNT(rp2.id) AS plan_count
                 FROM reseller_products rp
                 LEFT JOIN reseller_plans rp2 ON rp2.product_id=rp.id
                WHERE rp.api_project_id=? OR (rp.api_project_id IS NULL AND lower(rp.name)=lower(?))
                GROUP BY rp.id, rp.active
                ORDER BY CASE WHEN rp.api_project_id=? THEN 0 ELSE 1 END,
                         plan_count DESC, rp.id ASC""",
            (project_id, name, project_id),
        ).fetchall()

        if resellers:
            reseller_id = int(resellers[0]['id'])
            con.execute("UPDATE reseller_products SET api_project_id=?, name=?, active=? WHERE id=?",
                        (project_id, name, desired_active, reseller_id))
            for dup in resellers[1:]:
                dup_id = int(dup['id'])
                con.execute("UPDATE reseller_products SET active=0, api_project_id=NULL WHERE id=?", (dup_id,))
                con.execute("UPDATE reseller_plans SET active=0 WHERE product_id=?", (dup_id,))
        else:
            reseller_id = int(con.execute(
                "INSERT INTO reseller_products(name,active,api_project_id) VALUES(?,?,?)",
                (name, desired_active, project_id),
            ).lastrowid)

    con.commit()

def is_admin(user_id: int) -> bool:
    return str(user_id) == str(ADMIN_ID).strip()


def admin_kb():
    return InlineKeyboardMarkup([
        [b("📦 Products", "adm:products"), b("➕ Add Product", "adm:addprod")],
        [b("💰 Add Plan", "adm:addplan"), b("🔑 Add Key", "adm:addkey")],
        [b("👥 All Users", "adm:users"), b("💳 Manage Balance", "adm:balance")],
        [b("⭐ Make Reseller", "adm:reseller"), b("🚫 Ban / Unban", "adm:ban")],
        [b("📢 Broadcast", "adm:broadcast"), b("🔌 API Status", "adm:apistatus")],
        [b("⚙️ API Projects", "adm:apiprojects"), b("💳 Payment Gateway", "adm:payment")],
        [b("🔗 Links & Referral", "adm:links", "success"), b("🛠️ Maintenance", "adm:maintenance")],
        [b("🏪 Reseller Store", "adm:rproducts"), b("📁 Categories (Admin)", "adm:cats")],
        [b("🏠 Home", "home")],
    ])


def api_status_text():
    payment_ok = fampay_configured()
    cashfree_ok = cashfree_configured()
    bala_ok = bool(RESELLER_API_URL and RESELLER_API_KEY and RESELLER_MASTER_KEY)
    active = get_active_payment_gateway()
    projects = fetch_api_projects()
    pids = ", ".join(str(r["pid"]) for r in projects if str(r["pid"]).strip()) or "NONE"
    return (
        "🔌 API STATUS\n\n"
        f"💳 Fampay: {'🟢 READY / ON' if payment_ok and gateway_enabled('fampay') else '🔴 OFF / NOT READY'}\n"
        f"💳 Cashfree: {'🟢 READY / ON' if cashfree_ok and gateway_enabled('cashfree') else '🔴 OFF / NOT READY'}\n"
        f"⭐ Active Gateway: {active.upper() if active else 'NONE'}\n"
        f"🔑 Reseller API: {'🟢 CONFIGURED' if bala_ok else '🔴 NOT CONFIGURED'}\n"
        f"⚙️ Dynamic API Projects: {len(projects)}\n"
        f"🆔 Project PIDs: {pids}"
    )


def back_admin_kb():
    return InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])]])


def fetch_categories():
    con = db()
    rows = con.execute("SELECT id,name FROM categories ORDER BY id").fetchall()
    con.close()
    return rows


def fetch_products(category_id=None):
    con = db()
    if category_id is None:
        rows = con.execute("""SELECT p.id,p.name,p.category_id,c.name AS category,p.active
                             FROM products p JOIN categories c ON c.id=p.category_id
                             ORDER BY p.id""").fetchall()
    else:
        rows = con.execute("""SELECT id,name,category_id,active FROM products
                             WHERE category_id=? ORDER BY id""", (category_id,)).fetchall()
    con.close()
    return rows


def fetch_plans(product_id):
    con = db()
    rows = con.execute("""SELECT id,title,price,stock,active,api_duration FROM plans
                         WHERE product_id=? AND active=1 ORDER BY id""", (product_id,)).fetchall()
    con.close()
    return rows


def category_name(category_id):
    con = db()
    row = con.execute("SELECT name FROM categories WHERE id=?", (category_id,)).fetchone()
    con.close()
    return row["name"] if row else "Unknown Category"


def product_row(product_id):
    con = db()
    row = con.execute("""SELECT p.id,p.name,p.category_id,c.name AS category
                         FROM products p JOIN categories c ON c.id=p.category_id
                         WHERE p.id=?""", (product_id,)).fetchone()
    con.close()
    return row


def plan_row(plan_id):
    con = db()
    row = con.execute("""SELECT pl.id,pl.title,pl.price,pl.stock,pl.product_id,pl.api_duration,
                                p.name AS product,c.id AS category_id,c.name AS category
                         FROM plans pl JOIN products p ON p.id=pl.product_id
                         JOIN categories c ON c.id=p.category_id
                         WHERE pl.id=?""", (plan_id,)).fetchone()
    con.close()
    return row


def category_select_kb(prefix, include_back=True):
    rows = fetch_categories()
    kb = [[b(f"📁 {r['name']}", f"{prefix}:{r['id']}")] for r in rows]
    if include_back:
        kb.append([b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])])
    return InlineKeyboardMarkup(kb)


def product_select_kb(category_id, prefix, include_back=True):
    rows = fetch_products(category_id)
    kb = [[b(f"📦 {r['name']}", f"{prefix}:{r['id']}")] for r in rows]
    if include_back:
        kb.append([b(f"{FALLBACK['back']} BACK", f"adm:catmanage:{category_id}", "danger", EMOJI["back"])])
    return InlineKeyboardMarkup(kb)


def plan_select_kb(product_id, prefix, include_back=True):
    rows = fetch_plans(product_id)
    kb = []
    for r in rows:
        status = "OUT" if r["stock"] == 0 else f"stock {r['stock']}"
        kb.append([b(f"💰 {r['title']} — ₹{r['price']} ({status})", f"{prefix}:{r['id']}")])
    if not rows:
        kb.append([b("ℹ️ No plans yet", "noop")])
    if include_back:
        kb.append([b(f"{FALLBACK['back']} BACK", f"adm:prodmanage:{product_id}", "danger", EMOJI["back"])])
    return InlineKeyboardMarkup(kb)


def _customer_product_rows():
    rows = fetch_products()
    seen = set()
    result = []
    for r in rows:
        if not r["active"]:
            continue
        key = normalize_product_name(r["name"])
        if key in seen:
            continue
        seen.add(key)
        result.append(r)
    return result


def customer_category_kb():
    # Customer shop now shows products directly; old category callback remains compatible.
    rows = _customer_product_rows()
    kb = [[b(r["name"], f"shopprod:{r['id']}")] for r in rows]
    kb.append([b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])])
    return InlineKeyboardMarkup(kb)


def customer_reseller_kb():
    rows = _customer_product_rows()
    kb = [[b(r["name"], f"shopprod:{r['id']}")] for r in rows]
    kb.append([b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])])
    return InlineKeyboardMarkup(kb)



def customer_product_kb(category_id=None):
    rows = _customer_product_rows() if category_id is None else [r for r in fetch_products(category_id) if r["active"]]
    seen = set()
    kb = []
    for r in rows:
        key = normalize_product_name(r["name"])
        if key in seen:
            continue
        seen.add(key)
        kb.append([b(r["name"], f"shopprod:{r['id']}")])
    kb.append([b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])])
    return InlineKeyboardMarkup(kb)


def customer_plan_kb(product_id):
    rows = fetch_plans(product_id)
    kb = []
    product = product_row(product_id)
    is_api = is_api_product(product)
    for r in rows:
        if is_api:
            label = f"⏱️ {r['title']} • ₹{r['price']}"
            style = "primary"
        else:
            keys = available_key_count(r["id"])
            label = f"⏱️ {r['title']} • ₹{r['price']}" if keys > 0 else f"⏱️ {r['title']} • OUT OF STOCK"
            style = "primary" if keys > 0 else "danger"
        kb.append([b(label, f"walletbuy:{r['id']}", style)])
    if not rows:
        kb.append([b("⚠️ No plans available", "noop", "danger")])
    # From the plan screen, BACK must return to the product list.
    # The old callback pointed back to shopprod:<id>, which immediately reopened
    # the same plan screen and made BACK appear broken.
    kb.append([b(f"{FALLBACK['back']} BACK", "shop", "danger", EMOJI["back"])])
    return InlineKeyboardMarkup(kb)


def admin_categories_text():
    rows = fetch_categories()
    if not rows:
        return "📁 CATEGORIES\n\nNo categories yet."
    return "📁 CATEGORIES\n\n" + "\n".join(f"{r['id']}. {r['name']}" for r in rows)


def admin_products_text():
    rows = fetch_products()
    if not rows:
        return "📦 PRODUCTS\n\nNo products yet."
    return "📦 PRODUCTS\n\n" + "\n".join(
        f"{r['id']}. {r['name']} [{r['category']}] {'ON' if r['active'] else 'OFF'}"
        for r in rows
    )


def clear_admin_state(context):
    for key in list(context.user_data.keys()):
        if key.startswith("admin_"):
            context.user_data.pop(key, None)
    for key in ("category_id", "product_id", "plan_id", "new_title", "new_price", "new_stock", "plan_title", "plan_price"):
        context.user_data.pop(key, None)


def category_manage_kb(category_id):
    return InlineKeyboardMarkup([
        [b("📦 Products", f"adm:catproducts:{category_id}")],
        [b("➕ Add Product", f"adm:cataddprod:{category_id}")],
        [b("✏️ Rename Category", f"adm:editcat:{category_id}")],
        [b("🗑️ Delete Category", f"adm:delcat:{category_id}")],
        [b(f"{FALLBACK['back']} BACK", "adm:cats", "danger", EMOJI["back"])],
    ])


def product_manage_kb(product_id):
    return InlineKeyboardMarkup([
        [b("💰 View / Manage Plans", f"adm:plans:{product_id}")],
        [b("➕ Add Plan", f"adm:addplanfor:{product_id}")],
        [b("✏️ Rename Product", f"adm:editprod:{product_id}")],
        [b("🗑️ Delete Product", f"adm:delprod:{product_id}")],
        [b(f"{FALLBACK['back']} BACK", f"adm:catproducts:{product_row(product_id)['category_id']}" if product_row(product_id) else "adm:products")],
    ])


def plan_manage_kb(plan_id):
    row = plan_row(plan_id)
    back = f"adm:plans:{row['product_id']}" if row else "adm"
    return InlineKeyboardMarkup([
        [b("✏️ Edit Plan", f"adm:editplan:{plan_id}")],
        [b("🗑️ Delete Plan", f"adm:delplan:{plan_id}")],
        [b(f"{FALLBACK['back']} BACK", back, "danger", EMOJI["back"])],
    ])


def admin_target_kb(user_id):
    return InlineKeyboardMarkup([
        [b("➕ Add ₹", f"adm:user:add:{user_id}", "success"), b("➖ Remove ₹", f"adm:user:sub:{user_id}", "danger")],
        [b("⭐ Make Reseller", f"adm:user:reseller:{user_id}")],
        [b("🚫 Ban", f"adm:user:ban:{user_id}", "danger"), b("🟢 Unban", f"adm:user:unban:{user_id}", "success")],
        [b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])],
    ])


async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin only.")
        return
    clear_admin_state(context)
    await update.message.reply_text(
        "⚙️ NARESH ADMIN PANEL\n\nManage categories, products and plans:",
        reply_markup=admin_kb(),
    )


async def admin_cb(update: Update, context: ContextTypes.DEFAULT_TYPE, d: str):
    q = update.callback_query
    if not is_admin(q.from_user.id):
        await q.answer("Admin only.", show_alert=True)
        return

    if d == "adm:users":
        rows=list_users(); parts=["👥 ALL USERS\n"]
        for r in rows[:100]:
            parts.append(f"ID: {r['user_id']} | @{r['username'] or '-'} | ₹{money(r['balance'])} | {'RESELLER' if r['is_reseller'] else 'USER'} | {'BANNED' if r['banned'] else 'ACTIVE'}")
        await edit_current(q, "\n".join(parts) if rows else "👥 ALL USERS\n\nNo users found.", reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])]])); return
    if d in ("adm:balance","adm:reseller","adm:ban"):
        context.user_data["admin_action"]={"adm:balance":"find_balance","adm:reseller":"find_reseller","adm:ban":"find_ban"}[d]
        await edit_current(q, "👤 Send the user's Telegram numeric ID:", reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])]])); return
    if d == "adm:broadcast":
        context.user_data["admin_action"]="broadcast"
        await edit_current(q, "📢 BROADCAST\n\nSend text, photo, video or voice now. It will be copied to all non-banned users.", reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])]])); return
    if d.startswith("adm:user:"):
        parts=d.split(":"); uid=int(parts[-1]); r=user_summary(uid)
        if not r: await edit_current(q, "❌ User not found.", reply_markup=admin_kb()); return
        action=parts[2] if len(parts)>2 else "view"
        if action in ("add","sub"):
            context.user_data["admin_target"]=uid; context.user_data["admin_action"]="set_balance_add" if action=="add" else "set_balance_sub"
            await edit_current(q, "💰 Send amount:", reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", f"adm:user:view:{uid}", "danger", EMOJI["back"])]])); return
        if action=="reseller":
            con=db(); con.execute("UPDATE users SET is_reseller=1 WHERE user_id=?",(uid,)); con.commit(); con.close()
            await edit_current(q, "⭐ Reseller enabled for this user.", reply_markup=admin_target_kb(uid)); return
        if action in ("ban","unban"):
            con=db(); con.execute("UPDATE users SET banned=? WHERE user_id=?",(1 if action=="ban" else 0,uid)); con.commit(); con.close()
            await edit_current(q, "🚫 User banned." if action=="ban" else "🟢 User unbanned.", reply_markup=admin_target_kb(uid)); return
        await edit_current(q, f"👤 USER\n\nID: {uid}\nName: {r['full_name'] or '-'}\nUsername: @{r['username'] or '-'}\nBalance: ₹{money(r['balance'])}\nRole: {'RESELLER' if r['is_reseller'] else 'USER'}\nStatus: {'BANNED' if r['banned'] else 'ACTIVE'}", reply_markup=admin_target_kb(uid)); return

    if d == "noop":
        await q.answer()
        return

    if d == "adm":
        clear_admin_state(context)
        await edit_current(q, "⚙️ NARESH ADMIN PANEL\n\nManage your store:", reply_markup=admin_kb())
        return

    if d == "adm:payment":
        active = active_payment_gateway()
        await edit_current(
            q,
            "💳 PAYMENT GATEWAY SETTINGS\n\n"
            f"⭐ Active Gateway: {active.upper() if active else 'NONE'}\n"
            f"💳 Fampay: {'🟢 ON' if gateway_enabled('fampay') else '🔴 OFF'} | {'READY' if fampay_configured() else 'NOT READY'}\n"
            f"💳 Cashfree: {'🟢 ON' if gateway_enabled('cashfree') else '🔴 OFF'} | {'READY' if cashfree_configured() else 'NOT READY'}\n\n"
            "Choose a gateway to configure, turn ON/OFF, or make active.",
            reply_markup=InlineKeyboardMarkup([
                [b("💳 FAMPAY SETTINGS", "adm:pay:fampay", "primary")],
                [b("💳 CASHFREE SETTINGS", "adm:pay:cashfree", "primary")],
                [b("⭐ USE FAMPAY", "adm:pay:active:fampay", "success")],
                [b("⭐ USE CASHFREE", "adm:pay:active:cashfree", "success")],
                [b("🔙 BACK", "adm", "danger", EMOJI["back"])],
            ])
        )
        return

    if d == "adm:pay:fampay":
        await edit_current(
            q,
            "💳 FAMPAY SETTINGS\n\n"
            f"Status: {'🟢 ON' if gateway_enabled('fampay') else '🔴 OFF'}\n"
            f"API URL: {'SET' if payment_setting('fampay_api_url','PAYMENT_API_URL',PAYMENT_API_URL) else 'NOT SET'}\n"
            f"API Key: {'SET' if payment_setting('fampay_api_key','PAYMENT_API_KEY',PAYMENT_API_KEY) else 'NOT SET'}\n"
            f"UPI ID: {'SET' if payment_setting('fampay_upi_id','PAYMENT_UPI_ID',PAYMENT_UPI_ID) else 'NOT SET'}\n\n"
            "Use the buttons below to change the credentials or toggle Fampay.",
            reply_markup=InlineKeyboardMarkup([
                [b("🔗 SET API URL", "adm:pay:set:fampay_url")],
                [b("🔑 SET API KEY", "adm:pay:set:fampay_key")],
                [b("💰 SET UPI ID", "adm:pay:set:fampay_upi")],
                [b("🟢 ENABLE FAMPAY" if not gateway_enabled("fampay") else "🔴 DISABLE FAMPAY", "adm:pay:toggle:fampay")],
                [b("🔙 BACK", "adm:payment", "danger", EMOJI["back"])],
            ])
        )
        return

    if d == "adm:pay:cashfree":
        env = payment_setting("cashfree_environment","CASHFREE_ENVIRONMENT",CASHFREE_ENVIRONMENT).lower()
        await edit_current(
            q,
            "💳 CASHFREE SETTINGS\n\n"
            f"Status: {'🟢 ON' if gateway_enabled('cashfree') else '🔴 OFF'}\n"
            f"Client ID: {'SET' if payment_setting('cashfree_client_id','CASHFREE_CLIENT_ID',CASHFREE_CLIENT_ID) else 'NOT SET'}\n"
            f"Client Secret: {'SET' if payment_setting('cashfree_client_secret','CASHFREE_CLIENT_SECRET',CASHFREE_CLIENT_SECRET) else 'NOT SET'}\n"
            f"Customer Phone: {'SET' if payment_setting('cashfree_customer_phone','CASHFREE_CUSTOMER_PHONE',CASHFREE_CUSTOMER_PHONE) else 'NOT SET'}\n"
            f"Mode: {env.upper()}\n\n"
            "Cashfree uses its hosted payment link; no merchant UPI ID is required in this bot.",
            reply_markup=InlineKeyboardMarkup([
                [b("🆔 SET CLIENT ID", "adm:pay:set:cashfree_id")],
                [b("🔐 SET CLIENT SECRET", "adm:pay:set:cashfree_secret")],
                [b("📱 SET CUSTOMER PHONE", "adm:pay:set:cashfree_phone")],
                [b("🧪 SET SANDBOX MODE", "adm:pay:set:cashfree_sandbox")],
                [b("🚀 SET PRODUCTION MODE", "adm:pay:set:cashfree_production")],
                [b("🟢 ENABLE CASHFREE" if not gateway_enabled("cashfree") else "🔴 DISABLE CASHFREE", "adm:pay:toggle:cashfree")],
                [b("🔙 BACK", "adm:payment", "danger", EMOJI["back"])],
            ])
        )
        return

    if d.startswith("adm:pay:set:"):
        kind = d.split(":", 3)[3]
        prompts = {
            "fampay_url": "🔗 Send Fampay API URL:",
            "fampay_key": "🔑 Send Fampay API key:",
            "fampay_upi": "💰 Send Fampay UPI ID:",
            "cashfree_id": "🆔 Send Cashfree Client ID / App ID:",
            "cashfree_secret": "🔐 Send Cashfree Client Secret:",
            "cashfree_phone": "📱 Send a valid customer phone number (10 digits, e.g. 9876543210):",
        }
        if kind in ("cashfree_sandbox", "cashfree_production"):
            set_setting("cashfree_environment", "sandbox" if kind.endswith("sandbox") else "production")
            await edit_current(q, "✅ Cashfree mode updated.", reply_markup=InlineKeyboardMarkup([[b("🔙 BACK", "adm:pay:cashfree", "danger", EMOJI["back"])] ]))
            return
        if kind not in prompts:
            await q.answer("Unknown payment setting", show_alert=True)
            return
        clear_admin_state(context)
        context.user_data["admin_action"] = f"payment_{kind}"
        await edit_current(q, prompts[kind], reply_markup=InlineKeyboardMarkup([[b("🔙 BACK", "adm:payment", "danger", EMOJI["back"])] ]))
        return

    if d.startswith("adm:pay:toggle:"):
        gateway = d.split(":")[-1]
        if gateway not in ("fampay", "cashfree"):
            await q.answer("Unknown gateway", show_alert=True)
            return
        new_state = "0" if gateway_enabled(gateway) else "1"
        set_setting(f"{gateway}_enabled", new_state)
        if new_state == "0" and active_payment_gateway() == gateway:
            other = "cashfree" if gateway == "fampay" else "fampay"
            if gateway_enabled(other):
                set_setting("payment_gateway_active", other)
        await edit_current(q, f"✅ {gateway.upper()} is now {'ON' if new_state == '1' else 'OFF'}.", reply_markup=InlineKeyboardMarkup([[b("🔙 BACK", "adm:payment", "danger", EMOJI["back"])] ]))
        return

    if d.startswith("adm:pay:active:"):
        gateway = d.split(":")[-1]
        if gateway not in ("fampay", "cashfree") or not gateway_enabled(gateway):
            await edit_current(q, "⚠️ Gateway is OFF. Enable it first.", reply_markup=InlineKeyboardMarkup([[b("🔙 BACK", "adm:payment", "danger", EMOJI["back"])] ]))
            return
        if gateway == "fampay" and not fampay_configured():
            await edit_current(q, "⚠️ Fampay is not configured. Add API URL, API key and UPI ID first.", reply_markup=InlineKeyboardMarkup([[b("🔙 BACK", "adm:pay:fampay", "danger", EMOJI["back"])] ]))
            return
        if gateway == "cashfree" and not cashfree_configured():
            await edit_current(q, "⚠️ Cashfree is not configured. Add Client ID, Client Secret and Customer Phone first.", reply_markup=InlineKeyboardMarkup([[b("🔙 BACK", "adm:pay:cashfree", "danger", EMOJI["back"])] ]))
            return
        set_setting("payment_gateway_active", gateway)
        await edit_current(q, f"✅ {gateway.upper()} is now the ACTIVE payment gateway.", reply_markup=InlineKeyboardMarkup([[b("🔙 BACK", "adm:payment", "danger", EMOJI["back"])] ]))
        return

    if d == "adm:links":
        reward = referral_reward()
        dl = download_url() or "(not set)"
        tg = get_link_setting("support_telegram", "SUPPORT_USERNAME") or "(not set)"
        wa = get_link_setting("support_whatsapp", "SUPPORT_WHATSAPP") or "(not set)"
        await edit_current(q, 
            "🔗 LINKS & REFERRAL SETTINGS\n\n"
            f"📥 Download URL: {dl}\n"
            f"💬 Telegram Support: {tg}\n"
            f"📱 WhatsApp Support: {wa}\n"
            f"💰 Referral Reward: ₹{money(reward)} per successful referral\n\n"
            "Choose what you want to change:",
            reply_markup=InlineKeyboardMarkup([
                [b("📥 CHANGE DOWNLOAD LINK", "adm:setlink:download", "success")],
                [b("💬 CHANGE TELEGRAM LINK", "adm:setlink:telegram", "success")],
                [b("📱 CHANGE WHATSAPP LINK", "adm:setlink:whatsapp", "success")],
                [b("💰 CHANGE REFERRAL REWARD", "adm:setlink:reward", "success")],
                [b("🔙 BACK", "adm", "danger", EMOJI["back"])],
            ])
        )
        return

    if d.startswith("adm:setlink:"):
        kind = d.split(":", 2)[2]
        prompts = {
            "download": "📥 Send the new Download APK channel/link URL:",
            "telegram": "💬 Send the new Telegram support username or URL (example: @nareshdatiaofficial):",
            "whatsapp": "📱 Send the new WhatsApp number with country code or URL:",
            "reward": "💰 Send referral reward amount (example: 1):",
        }
        if kind not in prompts:
            await q.answer("Unknown setting", show_alert=True); return
        clear_admin_state(context)
        context.user_data["admin_action"] = f"setlink_{kind}"
        await edit_current(q, prompts[kind], reply_markup=InlineKeyboardMarkup([[b("🔙 BACK", "adm:links", "danger", EMOJI["back"])] ]))
        return

    if d == "adm:maintenance":
        enabled=maintenance_enabled(); set_setting("maintenance", "0" if enabled else "1")
        state="OFF" if enabled else "ON"
        await edit_current(q, f"🛠️ MAINTENANCE MODE: {state}\n\n" + ("Users can use the bot normally." if enabled else "All non-admin users will now see the maintenance message."), reply_markup=admin_kb()); return

    if d == "adm:rproducts":
        rows=fetch_reseller_products(); kb=[[b(f"📦 {r['name']} {'🟢' if r['active'] else '🔴'}",f"adm:rprod:{r['id']}")] for r in rows]
        kb.append([b("➕ ADD RESELLER PRODUCT","adm:raddprod","success")]); kb.append([b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])])
        await edit_current(q, "🏪 RESELLER STORE MANAGEMENT\n\nAdd separate products and reseller-only prices.", reply_markup=InlineKeyboardMarkup(kb)); return
    if d == "adm:raddprod":
        clear_admin_state(context); context.user_data['admin_action']='raddprod'; await edit_current(q, "➕ ADD RESELLER PRODUCT\n\nSend product name:"); return
    if d.startswith("adm:rprod:"):
        pid=int(d.split(":")[-1]); r=reseller_product_row(pid)
        if not r: await edit_current(q, "❌ Product not found.",reply_markup=admin_kb()); return
        plans=fetch_reseller_plans(pid); kb=[[b(f"💰 {p['title']} — ₹{p['price']} (stock {reseller_available_keys(p['id'])})",f"adm:rplan:{p['id']}")] for p in plans]
        kb += [[b("➕ ADD PLAN",f"adm:raddplan:{pid}","success")],[b("✏️ RENAME PRODUCT",f"adm:reditprod:{pid}"),b("🗑️ DELETE",f"adm:rdelprod:{pid}","danger")],[b(f"{FALLBACK['back']} BACK", "adm:rproducts", "danger", EMOJI["back"])]]
        await edit_current(q, f"🏪 RESELLER PRODUCT\n\n📦 {r['name']}\nPlans: {len(plans)}",reply_markup=InlineKeyboardMarkup(kb)); return
    if d.startswith("adm:raddplan:"):
        pid=int(d.split(":")[-1]); clear_admin_state(context); context.user_data['admin_action']='raddplan_title'; context.user_data['rproduct_id']=pid; await edit_current(q, "➕ ADD RESELLER PLAN\n\nSend plan title (example: 1 Hour):"); return
    if d.startswith("adm:rplan:"):
        pid=int(d.split(":")[-1]); r=reseller_plan_row(pid)
        if not r: await edit_current(q, "❌ Plan not found.",reply_markup=admin_kb()); return
        await edit_current(q, f"💰 RESELLER PLAN\n\nProduct: {r['product']}\nPlan: {r['title']}\nPrice: ₹{r['price']}\nStock: {reseller_available_keys(pid)}",reply_markup=InlineKeyboardMarkup([[b("✏️ EDIT PRICE",f"adm:reditprice:{pid}")],[b("➕ ADD KEY",f"adm:raddkey:{pid}","success")],[b("🗑️ DELETE PLAN",f"adm:rdelplan:{pid}","danger")],[b(f"{FALLBACK['back']} BACK", f"adm:rprod:{r['product_id']}", "danger", EMOJI["back"])]])); return
    if d.startswith("adm:reditprod:"):
        pid=int(d.split(":")[-1]); clear_admin_state(context); context.user_data['admin_action']='reditprod'; context.user_data['rproduct_id']=pid; await edit_current(q, "✏️ Send new reseller product name:"); return
    if d.startswith("adm:reditprice:"):
        pid=int(d.split(":")[-1]); clear_admin_state(context); context.user_data['admin_action']='reditprice'; context.user_data['rplan_id']=pid; await edit_current(q, "💰 Send new reseller price:"); return
    if d.startswith("adm:raddkey:"):
        pid=int(d.split(":")[-1]); clear_admin_state(context); context.user_data['admin_action']='raddkey'; context.user_data['rplan_id']=pid; await edit_current(q, "🔑 Send the reseller key to add to stock:"); return
    if d.startswith("adm:rdelprod:"):
        pid=int(d.split(":")[-1]); con=db(); con.execute("DELETE FROM reseller_keys WHERE plan_id IN (SELECT id FROM reseller_plans WHERE product_id=?)",(pid,)); con.execute("DELETE FROM reseller_plans WHERE product_id=?",(pid,)); con.execute("DELETE FROM reseller_products WHERE id=?",(pid,)); con.commit(); con.close(); await edit_current(q, "✅ Reseller product deleted.",reply_markup=admin_kb()); return
    if d.startswith("adm:rdelplan:"):
        pid=int(d.split(":")[-1]); r=reseller_plan_row(pid); con=db(); con.execute("DELETE FROM reseller_keys WHERE plan_id=?",(pid,)); con.execute("DELETE FROM reseller_plans WHERE id=?",(pid,)); con.commit(); con.close(); await edit_current(q, "✅ Reseller plan deleted.",reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", f"adm:rprod:{r['product_id']}" if r else "adm:rproducts", "danger", EMOJI["back"])]])); return

    if d == "adm:apiprojects":
        rows=fetch_api_projects()
        kb=[[b(f"{'🟢' if r['active'] else '🔴'} {r['name']} • PID {r['pid']}",f"adm:apiproj:{r['id']}")] for r in rows]
        kb.append([b("➕ ADD API PROJECT","adm:apiadd","success")])
        kb.append([b(f"{FALLBACK['back']} BACK","adm","danger",EMOJI["back"])])
        await edit_current(q,"⚙️ API PROJECTS\n\nManage future supplier projects without editing the source code. Set PID, endpoint, API key, master key, Android-ID requirement and selling plans.",reply_markup=InlineKeyboardMarkup(kb)); return

    if d == "adm:apiadd":
        clear_admin_state(context); context.user_data["admin_action"]="api_name"
        await edit_current(q,"➕ ADD API PROJECT\n\n1/6 Send project name.\nExample: DRIP CLIENT APK"); return

    if d.startswith("adm:apiproj:"):
        pid=int(d.split(":")[-1]); r=api_project_row(pid)
        if not r: await edit_current(q,"❌ API project not found.",reply_markup=InlineKeyboardMarkup([[b("🔙 BACK","adm:apiprojects")]])); return
        main_id, _ = ensure_api_project_products(r["name"], int(r["id"]))
        plans=fetch_plans(main_id) if main_id else []
        text=(f"⚙️ API PROJECT\n\n📦 Name: {r['name']}\n🆔 PID: {r['pid']}\n🔗 Endpoint: {r['endpoint'] or '(global default)'}\n🔐 API Key: {'SET' if r['api_key'] else 'NOT SET'}\n🔑 Master Key: {'SET' if r['master_key'] else 'NOT SET'}\n📱 Android ID: {'REQUIRED' if r['require_android_id'] else 'NOT REQUIRED'}\n📊 Status: {'ON' if r['active'] else 'OFF'}\n\nPlans: {len(plans)}")
        kb=[[b("➕ ADD PLAN",f"adm:apiaddplan:{pid}","success")],[b("✏️ NAME",f"adm:api_edit:{pid}:name"),b("🆔 PID",f"adm:api_edit:{pid}:pid")],[b("🔗 ENDPOINT",f"adm:api_edit:{pid}:endpoint"),b("🔑 API KEY",f"adm:api_edit:{pid}:api_key")],[b("🛡️ MASTER KEY",f"adm:api_edit:{pid}:master_key"),b("📱 ANDROID ID",f"adm:api_toggle_android:{pid}")],[b("🟢/🔴 ENABLE",f"adm:api_toggle:{pid}"),b("🗑️ DELETE",f"adm:api_delete:{pid}","danger")],[b("🔙 BACK","adm:apiprojects","danger")]]
        await edit_current(q,text,reply_markup=InlineKeyboardMarkup(kb)); return

    if d.startswith("adm:api_edit:"):
        _,_,pid,field=d.split(":",3); pid=int(pid); labels={"name":"project name","pid":"PID","endpoint":"API endpoint","api_key":"API key","master_key":"master key"}
        if field not in labels: return
        clear_admin_state(context); context.user_data["admin_action"]="api_edit_"+field; context.user_data["api_project_id"]=pid
        await edit_current(q,f"✏️ Send new {labels[field]}:"); return

    if d.startswith("adm:api_toggle:"):
        pid=int(d.split(":")[-1]); r=api_project_row(pid)
        if not r:
            await edit_current(q,"❌ API project not found.",reply_markup=InlineKeyboardMarkup([[b("🔙 BACK","adm:apiprojects")]])); return
        new_active = 0 if r["active"] else 1
        con=db()
        con.execute("UPDATE api_projects SET active=? WHERE id=?",(new_active,pid))
        con.execute("UPDATE products SET active=? WHERE api_project_id=?",(new_active,pid))
        con.execute("UPDATE reseller_products SET active=? WHERE api_project_id=?",(new_active,pid))
        con.commit(); con.close()
        await edit_current(q,"✅ API project status updated.\n\nStore visibility: " + ("🟢 ON" if new_active else "🔴 OFF"),reply_markup=InlineKeyboardMarkup([[b("🔙 BACK",f"adm:apiproj:{pid}")]])); return

    if d.startswith("adm:api_toggle_android:"):
        pid=int(d.split(":")[-1]); r=api_project_row(pid)
        if r:
            con=db(); con.execute("UPDATE api_projects SET require_android_id=? WHERE id=?",(0 if r["require_android_id"] else 1,pid)); con.commit(); con.close()
        await edit_current(q,"✅ Android ID requirement updated.",reply_markup=InlineKeyboardMarkup([[b("🔙 BACK",f"adm:apiproj:{pid}")]])); return

    if d.startswith("adm:api_delete:"):
        pid=int(d.split(":")[-1]); r=api_project_row(pid)
        if not r:
            await edit_current(q,"❌ API project not found.",reply_markup=InlineKeyboardMarkup([[b("🔙 API PROJECTS","adm:apiprojects")]])); return
        # Keep purchase history and foreign-key rows safe. Disable only the
        # canonical rows linked to this API project, then remove its mapping.
        con=db()
        con.execute("UPDATE products SET active=0 WHERE api_project_id=?",(pid,))
        con.execute("UPDATE plans SET active=0 WHERE product_id IN (SELECT id FROM products WHERE api_project_id=?)",(pid,))
        con.execute("UPDATE reseller_products SET active=0 WHERE api_project_id=?",(pid,))
        con.execute("UPDATE reseller_plans SET active=0 WHERE product_id IN (SELECT id FROM reseller_products WHERE api_project_id=?)",(pid,))
        con.execute("DELETE FROM api_projects WHERE id=?",(pid,))
        # Mapping columns are nullable so old product/purchase rows remain intact.
        con.execute("UPDATE products SET api_project_id=NULL WHERE api_project_id=?",(pid,))
        con.execute("UPDATE reseller_products SET api_project_id=NULL WHERE api_project_id=?",(pid,))
        con.commit(); con.close()
        await edit_current(q,"✅ API project removed.\n\nOnly this project's store product and plans were disabled.",reply_markup=InlineKeyboardMarkup([[b("🔙 API PROJECTS","adm:apiprojects")]])); return

    if d.startswith("adm:apiaddplan:"):
        pid=int(d.split(":")[-1]); r=api_project_row(pid)
        if not r: return
        clear_admin_state(context); context.user_data["admin_action"]="api_plan_title"; context.user_data["api_project_id"]=pid
        await edit_current(q,f"➕ ADD PLAN\n\nProject: {r['name']}\n\n1/3 Send shop plan title.\nExample: 7 Days"); return

    if d == "adm:apistatus":
        await edit_current(q, 
            api_status_text(),
            reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])]])
        )
        return

    if d == "adm:cats":
        rows = fetch_categories()
        text = admin_categories_text() + "\n\n👇 Tap a category to manage it."
        kb = InlineKeyboardMarkup(
            [[b(f"📁 {r['name']}", f"adm:catmanage:{r['id']}")] for r in rows] +
            [[b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])]]
        )
        await edit_current(q, text, reply_markup=kb)
        return

    if d == "adm:products":
        rows = fetch_categories()
        kb = [[b(f"📁 {r['name']}", f"adm:catproducts:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])])
        await edit_current(q, "📦 PRODUCTS\n\nChoose category first:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d == "adm:addcat":
        clear_admin_state(context)
        context.user_data["admin_action"] = "addcat"
        await edit_current(q, "➕ ADD CATEGORY\n\nSend the category name now.\nExample: NON ROOT - ANDROID")
        return

    if d == "adm:addprod":
        clear_admin_state(context)
        rows = fetch_categories()
        if not rows:
            await edit_current(q, "⚠️ First add a category.", reply_markup=admin_kb())
            return
        kb = [[b(f"📁 {r['name']}", f"adm:addprodcat:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])])
        await edit_current(q, "➕ ADD PRODUCT\n\nChoose category:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:addprodcat:") or d.startswith("adm:cataddprod:"):
        cat_id = int(d.split(":")[-1])
        clear_admin_state(context)
        context.user_data["admin_action"] = "addprod"
        context.user_data["category_id"] = cat_id
        await edit_current(q, f"📦 ADD PRODUCT\n\nCategory: {category_name(cat_id)}\n\nSend product name.\nExample: Drip Client")
        return

    if d == "adm:addkey":
        clear_admin_state(context)
        rows = fetch_categories()
        if not rows:
            await edit_current(q, "⚠️ First add a category.", reply_markup=admin_kb())
            return
        kb = [[b(f"📁 {r['name']}", f"adm:addkeycat:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])])
        await edit_current(q, "🔑 ADD KEY\n\nChoose category:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:addkeycat:"):
        cat_id = int(d.split(":")[-1])
        rows = fetch_products(cat_id)
        kb = [[b(r["name"], f"adm:addkeyprod:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", f"adm:catmanage:{cat_id}", "danger", EMOJI["back"])])
        await edit_current(q, f"🔑 ADD KEY\n\nCategory: {category_name(cat_id)}\n\nChoose product:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:addkeyprod:"):
        product_id = int(d.split(":")[-1])
        rows = fetch_plans(product_id)
        kb = [[b(f"💰 {r['title']} — ₹{r['price']}", f"adm:addkeyplan:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", f"adm:prodmanage:{product_id}", "danger", EMOJI["back"])])
        await edit_current(q, "🔑 ADD KEY\n\nChoose plan:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:addkeyplan:"):
        plan_id = int(d.split(":")[-1])
        row = plan_row(plan_id)
        if not row:
            await edit_current(q, "❌ Plan not found.", reply_markup=admin_kb())
            return
        clear_admin_state(context)
        context.user_data["admin_action"] = "addkey"
        context.user_data["plan_id"] = plan_id
        await edit_current(q, 
            f"🔑 ADD KEY\n\nCategory: {row['category']}\nProduct: {row['product']}\nPlan: {row['title']}\n\nSend the key to store:"
        )
        return

    if d == "adm:addplan":
        clear_admin_state(context)
        rows = fetch_categories()
        if not rows:
            await edit_current(q, "⚠️ First add a category.", reply_markup=admin_kb())
            return
        kb = [[b(f"📁 {r['name']}", f"adm:addplancat:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])])
        await edit_current(q, "💰 ADD PLAN\n\nChoose category:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:addplancat:"):
        cat_id = int(d.split(":")[-1])
        rows = fetch_products(cat_id)
        if not rows:
            await edit_current(q, "⚠️ This category has no products. Add a product first.", reply_markup=category_manage_kb(cat_id))
            return
        kb = [[b(f"📦 {r['name']}", f"adm:addplanfor:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", f"adm:catmanage:{cat_id}", "danger", EMOJI["back"])])
        await edit_current(q, 
            f"💰 ADD PLAN\n\nCategory: {category_name(cat_id)}\n\nChoose product:",
            reply_markup=InlineKeyboardMarkup(kb),
        )
        return

    if d.startswith("adm:addplanfor:"):
        product_id = int(d.split(":")[-1])
        row = product_row(product_id)
        if not row:
            await edit_current(q, "❌ Product not found.", reply_markup=admin_kb())
            return
        clear_admin_state(context)
        context.user_data["admin_action"] = "addplan_title"
        context.user_data["product_id"] = product_id
        api_note = "\n\nFor API products, stock is automatic — only title + price are needed." if is_api_product(row) else "\n\nAfter price, stock quantity will be requested."
        await edit_current(q, 
            f"💰 ADD PLAN\n\nProduct: {row['name']}\nCategory: {row['category']}\n\nSend plan title.\nExample: 1 Day{api_note}"
        )
        return

    if d.startswith("adm:catmanage:"):
        cat_id = int(d.split(":")[-1])
        name = category_name(cat_id)
        await edit_current(q, 
            f"📁 CATEGORY MANAGEMENT\n\nCategory: {name}\n\nChoose an action:",
            reply_markup=category_manage_kb(cat_id),
        )
        return

    if d.startswith("adm:catproducts:"):
        cat_id = int(d.split(":")[-1])
        rows = fetch_products(cat_id)
        kb = [[b(f"📦 {r['name']}", f"adm:prodmanage:{r['id']}")] for r in rows]
        kb += [[b("➕ Add Product", f"adm:cataddprod:{cat_id}")], [b(f"{FALLBACK['back']} BACK", f"adm:catmanage:{cat_id}", "danger", EMOJI["back"])]]
        await edit_current(q, 
            f"📦 PRODUCTS\n\nCategory: {category_name(cat_id)}\n\nTap a product to manage it:",
            reply_markup=InlineKeyboardMarkup(kb),
        )
        return

    if d.startswith("adm:prodmanage:"):
        product_id = int(d.split(":")[-1])
        row = product_row(product_id)
        if not row:
            await edit_current(q, "❌ Product not found.", reply_markup=admin_kb())
            return
        plans = fetch_plans(product_id)
        await edit_current(q, 
            f"📦 PRODUCT MANAGEMENT\n\nProduct: {row['name']}\nCategory: {row['category']}\nPlans: {len(plans)}\n\nChoose an action:",
            reply_markup=product_manage_kb(product_id),
        )
        return

    if d.startswith("adm:plans:"):
        product_id = int(d.split(":")[-1])
        row = product_row(product_id)
        if not row:
            await edit_current(q, "❌ Product not found.", reply_markup=admin_kb())
            return
        plans = fetch_plans(product_id)
        text = f"💰 PLAN MANAGEMENT\n\nProduct: {row['name']}\nCategory: {row['category']}\n\n"
        text += "Tap a plan to edit/delete it." if plans else "No plans yet. Tap Add Plan."
        kb = [[b(f"💰 {p['title']} — ₹{p['price']} (stock {p['stock']})", f"adm:planmanage:{p['id']}")] for p in plans]
        kb += [[b("➕ Add Plan", f"adm:addplanfor:{product_id}")], [b(f"{FALLBACK['back']} BACK", f"adm:prodmanage:{product_id}", "danger", EMOJI["back"])]]
        await edit_current(q, text, reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:planmanage:"):
        plan_id = int(d.split(":")[-1])
        row = plan_row(plan_id)
        if not row:
            await edit_current(q, "❌ Plan not found.", reply_markup=admin_kb())
            return
        await edit_current(q, 
            f"💰 PLAN MANAGEMENT\n\nCategory: {row['category']}\nProduct: {row['product']}\nPlan: {row['title']}\nPrice: ₹{row['price']}\nStock: {row['stock']}\n\nChoose an action:",
            reply_markup=plan_manage_kb(plan_id),
        )
        return

    if d == "adm:edit":
        await edit_current(q, 
            "✏️ EDIT\n\nFirst choose what you want to edit:",
            reply_markup=InlineKeyboardMarkup([
                [b("📁 Category", "adm:editcatlist")],
                [b("📦 Product", "adm:editprodlist")],
                [b("💰 Plan", "adm:editplanlist")],
                [b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])],
            ]),
        )
        return

    if d == "adm:delete":
        await edit_current(q, 
            "🗑️ DELETE\n\nChoose what you want to delete:",
            reply_markup=InlineKeyboardMarkup([
                [b("📁 Category", "adm:delcatlist")],
                [b("📦 Product", "adm:delprodlist")],
                [b("💰 Plan", "adm:delplanlist")],
                [b(f"{FALLBACK['back']} BACK", "adm", "danger", EMOJI["back"])],
            ]),
        )
        return

    if d == "adm:editcatlist" or d == "adm:delcatlist":
        prefix = "adm:editcat" if d.endswith("editcatlist") else "adm:delcat"
        title = "✏️ EDIT CATEGORY" if prefix == "adm:editcat" else "🗑️ DELETE CATEGORY"
        rows = fetch_categories()
        kb = [[b(r["name"], f"{prefix}:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm:edit" if prefix == "adm:editcat" else "adm:delete", "danger", EMOJI["back"])])
        await edit_current(q, f"{title}\n\nChoose category:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:editcat:"):
        cat_id = int(d.split(":")[-1])
        row = next((r for r in fetch_categories() if r["id"] == cat_id), None)
        if not row:
            await edit_current(q, "❌ Category not found.", reply_markup=admin_kb())
            return
        clear_admin_state(context)
        context.user_data["admin_action"] = "editcat"
        context.user_data["category_id"] = cat_id
        await edit_current(q, f"✏️ RENAME CATEGORY\n\nCurrent name: {row['name']}\n\nSend new name:")
        return

    if d.startswith("adm:delcat:"):
        cat_id = int(d.split(":")[-1])
        name = category_name(cat_id)
        await edit_current(q, 
            f"⚠️ DELETE CATEGORY\n\nCategory: {name}\n\nThis will delete all products and plans inside it.\nAre you sure?",
            reply_markup=InlineKeyboardMarkup([
                [b("✅ YES, DELETE", f"adm:confirmdelcat:{cat_id}", "danger")],
                [b("❌ Cancel", f"adm:catmanage:{cat_id}")],
            ]),
        )
        return

    if d.startswith("adm:confirmdelcat:"):
        cat_id = int(d.split(":")[-1])
        con = db()
        con.execute("DELETE FROM plans WHERE product_id IN (SELECT id FROM products WHERE category_id=?)", (cat_id,))
        con.execute("DELETE FROM products WHERE category_id=?", (cat_id,))
        con.execute("DELETE FROM categories WHERE id=?", (cat_id,))
        con.commit()
        con.close()
        await edit_current(q, "✅ Category, its products and its plans were deleted.", reply_markup=admin_kb())
        return

    if d == "adm:editprodlist" or d == "adm:delprodlist":
        title = "✏️ EDIT PRODUCT" if d == "adm:editprodlist" else "🗑️ DELETE PRODUCT"
        action = "adm:editprodcat" if d == "adm:editprodlist" else "adm:delprodcat"
        rows = fetch_categories()
        kb = [[b(f"📁 {r['name']}", f"{action}:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm:edit" if d == "adm:editprodlist" else "adm:delete", "danger", EMOJI["back"])])
        await edit_current(q, f"{title}\n\nChoose category first:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:editprodcat:") or d.startswith("adm:delprodcat:"):
        cat_id = int(d.split(":")[-1])
        prefix = "adm:editprod" if d.startswith("adm:editprodcat:") else "adm:delprod"
        title = "✏️ EDIT PRODUCT" if prefix == "adm:editprod" else "🗑️ DELETE PRODUCT"
        rows = fetch_products(cat_id)
        kb = [[b(r["name"], f"{prefix}:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm:editprodlist" if prefix == "adm:editprod" else "adm:delprodlist", "danger", EMOJI["back"])])
        await edit_current(q, f"{title}\n\nCategory: {category_name(cat_id)}\n\nChoose product:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:editprod:"):
        product_id = int(d.split(":")[-1])
        row = product_row(product_id)
        if not row:
            await edit_current(q, "❌ Product not found.", reply_markup=admin_kb())
            return
        clear_admin_state(context)
        context.user_data["admin_action"] = "editprod"
        context.user_data["product_id"] = product_id
        await edit_current(q, f"✏️ RENAME PRODUCT\n\nCategory: {row['category']}\nCurrent name: {row['name']}\n\nSend new name:")
        return

    if d.startswith("adm:delprod:"):
        product_id = int(d.split(":")[-1])
        row = product_row(product_id)
        if not row:
            await edit_current(q, "❌ Product not found.", reply_markup=admin_kb())
            return
        await edit_current(q, 
            f"⚠️ DELETE PRODUCT\n\nCategory: {row['category']}\nProduct: {row['name']}\n\nAll plans inside this product will also be deleted.\nAre you sure?",
            reply_markup=InlineKeyboardMarkup([
                [b("✅ YES, DELETE", f"adm:confirmdelprod:{product_id}", "danger")],
                [b("❌ Cancel", f"adm:prodmanage:{product_id}")],
            ]),
        )
        return

    if d.startswith("adm:confirmdelprod:"):
        product_id = int(d.split(":")[-1])
        con = db()
        con.execute("DELETE FROM plans WHERE product_id=?", (product_id,))
        con.execute("DELETE FROM products WHERE id=?", (product_id,))
        con.commit()
        con.close()
        await edit_current(q, "✅ Product and its plans were deleted.", reply_markup=admin_kb())
        return

    if d == "adm:editplanlist" or d == "adm:delplanlist":
        action = "adm:editplancat" if d == "adm:editplanlist" else "adm:delplancat"
        title = "✏️ EDIT PLAN" if d == "adm:editplanlist" else "🗑️ DELETE PLAN"
        rows = fetch_categories()
        kb = [[b(f"📁 {r['name']}", f"{action}:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm:edit" if d == "adm:editplanlist" else "adm:delete", "danger", EMOJI["back"])])
        await edit_current(q, f"{title}\n\nChoose category first:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:editplancat:") or d.startswith("adm:delplancat:"):
        cat_id = int(d.split(":")[-1])
        prefix = "adm:editplanprod" if d.startswith("adm:editplancat:") else "adm:delplanprod"
        title = "✏️ EDIT PLAN" if prefix == "adm:editplanprod" else "🗑️ DELETE PLAN"
        rows = fetch_products(cat_id)
        kb = [[b(r["name"], f"{prefix}:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", "adm:editplanlist" if prefix == "adm:editplanprod" else "adm:delplanlist", "danger", EMOJI["back"])])
        await edit_current(q, f"{title}\n\nCategory: {category_name(cat_id)}\n\nChoose product:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:editplanprod:") or d.startswith("adm:delplanprod:"):
        product_id = int(d.split(":")[-1])
        prefix = "adm:editplan" if d.startswith("adm:editplanprod:") else "adm:delplan"
        title = "✏️ EDIT PLAN" if prefix == "adm:editplan" else "🗑️ DELETE PLAN"
        rows = fetch_plans(product_id)
        kb = [[b(f"💰 {r['title']} — ₹{r['price']}", f"{prefix}:{r['id']}")] for r in rows]
        kb.append([b(f"{FALLBACK['back']} BACK", f"adm:prodmanage:{product_id}", "danger", EMOJI["back"])])
        await edit_current(q, f"{title}\n\nChoose plan:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if d.startswith("adm:editplan:"):
        plan_id = int(d.split(":")[-1])
        row = plan_row(plan_id)
        if not row:
            await edit_current(q, "❌ Plan not found.", reply_markup=admin_kb())
            return
        clear_admin_state(context)
        context.user_data["admin_action"] = "editplan_title"
        context.user_data["plan_id"] = plan_id
        await edit_current(q, 
            f"✏️ EDIT PLAN\n\nProduct: {row['product']}\nCurrent plan: {row['title']}\nCurrent price: ₹{row['price']}\nCurrent stock: {row['stock']}\n\nSend new plan title:")
        return

    if d.startswith("adm:delplan:"):
        plan_id = int(d.split(":")[-1])
        row = plan_row(plan_id)
        if not row:
            await edit_current(q, "❌ Plan not found.", reply_markup=admin_kb())
            return
        await edit_current(q, 
            f"⚠️ DELETE PLAN\n\nProduct: {row['product']}\nPlan: {row['title']}\nPrice: ₹{row['price']}\n\nAre you sure?",
            reply_markup=InlineKeyboardMarkup([
                [b("✅ YES, DELETE", f"adm:confirmdelplan:{plan_id}", "danger")],
                [b("❌ Cancel", f"adm:planmanage:{plan_id}")],
            ]),
        )
        return

    if d.startswith("adm:confirmdelplan:"):
        plan_id = int(d.split(":")[-1])
        con = db()
        con.execute("DELETE FROM plans WHERE id=?", (plan_id,))
        con.commit()
        con.close()
        await edit_current(q, "✅ Plan deleted.", reply_markup=admin_kb())
        return

    await q.answer("Unknown admin action", show_alert=True)


async def admin_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if is_admin(update.effective_user.id):
        action=context.user_data.get("admin_action")
        if action == "broadcast":
            msg=update.message; con=db(); ids=[r["user_id"] for r in con.execute("SELECT user_id FROM users WHERE banned=0").fetchall()]; con.close(); ok=fail=0
            for uid in ids:
                try: await context.bot.copy_message(chat_id=uid, from_chat_id=msg.chat_id, message_id=msg.message_id); ok+=1
                except Exception: fail+=1
            context.user_data.pop("admin_action",None); await msg.reply_text(f"📢 BROADCAST COMPLETE\n\n✅ Sent: {ok}\n❌ Failed: {fail}", reply_markup=admin_kb()); return
        if action in ("find_balance","find_reseller","find_ban"):
            try: uid=int((update.message.text or "").strip())
            except ValueError: await update.message.reply_text("⚠️ Send numeric Telegram ID."); return
            if not user_summary(uid): await update.message.reply_text("❌ User not found.", reply_markup=admin_kb()); return
            context.user_data["admin_action"]="user_view"; context.user_data["admin_target"]=uid
            await update.message.reply_text("👤 User selected.", reply_markup=admin_target_kb(uid)); return
        if action in ("set_balance_add","set_balance_sub"):
            try: amount=float((update.message.text or "").strip().replace(",","")); assert amount>0
            except Exception: await update.message.reply_text("⚠️ Enter a valid positive amount."); return
            uid=int(context.user_data["admin_target"]); delta=amount if action=="set_balance_add" else -amount
            con=db(); con.execute("UPDATE users SET balance=ROUND(balance+?,2),updated_at=CURRENT_TIMESTAMP WHERE user_id=?",(delta,uid)); con.commit(); con.close()
            context.user_data["admin_action"]="user_view"; await update.message.reply_text(f"✅ Balance updated. New balance: ₹{money(get_balance(uid))}", reply_markup=admin_target_kb(uid)); return
        if action in ("api_name","api_pid","api_endpoint","api_key","api_master_key","api_edit_name","api_edit_pid","api_edit_endpoint","api_edit_api_key","api_edit_master_key"):
            value=(update.message.text or "").strip()
            if not value: await update.message.reply_text("⚠️ Value cannot be empty."); return
            if action in ("api_endpoint","api_edit_endpoint") and value!="-" and not value.startswith(("http://","https://")):
                await update.message.reply_text("⚠️ Endpoint must start with http:// or https://"); return
            if action=="api_name": context.user_data["api_name"]=value; context.user_data["admin_action"]="api_pid"; await update.message.reply_text("2/6 Send supplier PID / product ID:"); return
            if action=="api_pid": context.user_data["api_pid"]=value; context.user_data["admin_action"]="api_endpoint"; await update.message.reply_text("3/6 Send API endpoint.\nSend - to use global RESELLER_API_URL:"); return
            if action=="api_endpoint": context.user_data["api_endpoint"]="" if value=="-" else value; context.user_data["admin_action"]="api_key"; await update.message.reply_text("4/6 Send API key:"); return
            if action=="api_key": context.user_data["api_key"]=value; context.user_data["admin_action"]="api_master_key"; await update.message.reply_text("5/6 Send master key (or - if not needed):"); return
            if action=="api_master_key": context.user_data["api_master_key"]="" if value=="-" else value; context.user_data["admin_action"]="api_android"; await update.message.reply_text("6/6 Android ID required? Reply YES or NO:"); return
            field=action.replace("api_edit_",""); pid=int(context.user_data.get("api_project_id"));
            if field in {"name","pid","endpoint","api_key","master_key"}:
                value="" if value=="-" else value
                try:
                    if field=="name":
                        con0=db(); project=con0.execute("SELECT name FROM api_projects WHERE id=?",(pid,)).fetchone(); con0.close()
                        if not project:
                            context.user_data.clear(); await update.message.reply_text("❌ API project not found.",reply_markup=admin_kb()); return
                        old_name=str(project["name"])
                        # Make sure legacy rows are mapped before renaming.
                        ensure_api_project_products(old_name,pid)
                    con=db()
                    project=con.execute("SELECT name FROM api_projects WHERE id=?",(pid,)).fetchone()
                    if not project:
                        con.close(); context.user_data.clear(); await update.message.reply_text("❌ API project not found.",reply_markup=admin_kb()); return
                    if field=="name":
                        con.execute("UPDATE api_projects SET name=? WHERE id=?",(value,pid))
                        con.execute("UPDATE products SET name=? WHERE api_project_id=?",(value,pid))
                        con.execute("UPDATE reseller_products SET name=? WHERE api_project_id=?",(value,pid))
                    else:
                        con.execute(f"UPDATE api_projects SET {field}=? WHERE id=?",(value,pid))
                    con.commit(); con.close()
                except sqlite3.IntegrityError:
                    try: con.close()
                    except Exception: pass
                    await update.message.reply_text("⚠️ A project with this name already exists."); return
                context.user_data.clear(); await update.message.reply_text("✅ API project updated.",reply_markup=admin_kb()); return

        if action=="api_android":
            value=(update.message.text or "").strip().lower()
            if value not in ("yes","no","y","n"): await update.message.reply_text("⚠️ Reply YES or NO."); return
            try:
                con=db()
                cur=con.execute("INSERT INTO api_projects(name,pid,endpoint,api_key,master_key,require_android_id,active) VALUES(?,?,?,?,?,?,0)",(context.user_data["api_name"],context.user_data["api_pid"],context.user_data.get("api_endpoint",""),context.user_data.get("api_key",""),context.user_data.get("api_master_key",""),1 if value in ("yes","y") else 0))
                project_id=int(cur.lastrowid)
                con.commit(); con.close()
                # Create exactly one mapped customer product and reseller product.
                ensure_api_project_products(context.user_data["api_name"], project_id)
            except sqlite3.IntegrityError:
                try: con.close()
                except Exception: pass
                await update.message.reply_text("⚠️ A project with this name already exists."); return
            name=context.user_data["api_name"]; context.user_data.clear(); await update.message.reply_text(f"✅ API PROJECT CREATED\n\n📦 {name}\n\nOpen /admin → API Projects → project → ADD PLAN.",reply_markup=admin_kb()); return

        if action=="api_plan_title":
            value=(update.message.text or "").strip()
            if not value: await update.message.reply_text("⚠️ Plan title cannot be empty."); return
            context.user_data["api_plan_title"]=value; context.user_data["admin_action"]="api_plan_duration"; await update.message.reply_text("2/3 Send supplier duration exactly as API expects.\nExample: 7 Days"); return

        if action=="api_plan_duration":
            value=(update.message.text or "").strip()
            if not value: await update.message.reply_text("⚠️ Duration cannot be empty."); return
            context.user_data["api_plan_duration"]=value; context.user_data["admin_action"]="api_plan_price"; await update.message.reply_text("3/3 Send selling price in ₹. Example: 499"); return

        if action=="api_plan_price":
            value=(update.message.text or "").strip().replace(",","")
            try: price=int(float(value)); assert price>0
            except Exception: await update.message.reply_text("⚠️ Enter a valid positive price."); return
            project=api_project_row(int(context.user_data["api_project_id"]))
            if not project: context.user_data.clear(); await update.message.reply_text("❌ API project not found.",reply_markup=admin_kb()); return
            main_id,res_id=ensure_api_project_products(project["name"], int(project["id"]))
            con=db();
            con.execute("INSERT INTO plans(product_id,title,price,stock,active,api_duration) VALUES(?,?,?,0,1,?)",(main_id,context.user_data["api_plan_title"],price,context.user_data["api_plan_duration"]));
            con.execute("INSERT INTO reseller_plans(product_id,title,price,stock,active,api_duration) VALUES(?,?,?,0,1,?)",(res_id,context.user_data["api_plan_title"],price,context.user_data["api_plan_duration"]));
            con.commit(); con.close();
            context.user_data.clear();
            await update.message.reply_text("✅ PLAN ADDED\n\nThe plan is now available in the bot shop and reseller store. Delivery uses this project's PID and supplier duration.",reply_markup=admin_kb()); return

        if action.startswith("payment_"):
            value = (update.message.text or "").strip()
            if not value:
                await update.message.reply_text("⚠️ Value cannot be empty.")
                return
            key_map = {
                "payment_fampay_url": "fampay_api_url",
                "payment_fampay_key": "fampay_api_key",
                "payment_fampay_upi": "fampay_upi_id",
                "payment_cashfree_id": "cashfree_client_id",
                "payment_cashfree_secret": "cashfree_client_secret",
                "payment_cashfree_phone": "cashfree_customer_phone",
            }
            key = key_map.get(action)
            if not key:
                await update.message.reply_text("⚠️ Unknown payment setting.", reply_markup=admin_kb())
                context.user_data.pop("admin_action", None)
                return
            if key == "fampay_api_url" and not value.startswith(("http://", "https://")):
                await update.message.reply_text("⚠️ API URL must start with http:// or https://.")
                return
            if key == "fampay_upi_id" and ("@" not in value or any(ch.isspace() for ch in value)):
                await update.message.reply_text("⚠️ Enter a valid UPI ID, e.g. merchant@upi.")
                return
            if key == "cashfree_customer_phone":
                digits = "".join(ch for ch in value if ch.isdigit())
                if len(digits) != 10:
                    await update.message.reply_text("⚠️ Enter a valid 10-digit customer phone number.")
                    return
                value = digits
            set_setting(key, value)
            context.user_data.pop("admin_action", None)
            gateway = "fampay" if key.startswith("fampay_") else "cashfree"
            await update.message.reply_text(
                f"✅ {gateway.upper()} setting updated.\n\n"
                "Open Admin → Payment Gateway again to enable it or make it active.",
                reply_markup=admin_kb()
            )
            return

        if action in ("setlink_download", "setlink_telegram", "setlink_whatsapp", "setlink_reward"):
            value = (update.message.text or "").strip()
            if action == "setlink_download":
                if not value.startswith(("https://", "http://", "tg://")):
                    await update.message.reply_text("⚠️ Send a valid URL starting with https://", reply_markup=admin_kb()); return
                set_setting("download_url", value)
                context.user_data.pop("admin_action", None)
                await update.message.reply_text("✅ Download link updated.", reply_markup=admin_kb()); return
            if action == "setlink_telegram":
                if value.startswith("https://t.me/"):
                    username = value.rstrip("/").split("/")[-1]
                else:
                    username = value.lstrip("@").strip()
                if not username or any(ch.isspace() for ch in username):
                    await update.message.reply_text("⚠️ Send a valid Telegram username or https://t.me/... link.", reply_markup=admin_kb()); return
                set_setting("support_telegram", "@" + username)
                context.user_data.pop("admin_action", None)
                await update.message.reply_text("✅ Telegram support link updated.", reply_markup=admin_kb()); return
            if action == "setlink_whatsapp":
                raw = value
                if raw.startswith(("https://wa.me/", "http://wa.me/")):
                    raw = raw.split("/")[-1]
                digits = "".join(ch for ch in raw if ch.isdigit())
                if len(digits) < 8:
                    await update.message.reply_text("⚠️ Send a valid WhatsApp number with country code.", reply_markup=admin_kb()); return
                set_setting("support_whatsapp", digits)
                context.user_data.pop("admin_action", None)
                await update.message.reply_text("✅ WhatsApp support link updated.", reply_markup=admin_kb()); return
            if action == "setlink_reward":
                try:
                    amount = float(value.replace(",", ""))
                    if amount < 0 or amount > 100000: raise ValueError
                except Exception:
                    await update.message.reply_text("⚠️ Enter a valid reward amount, e.g. 1"); return
                set_setting("referral_reward", amount)
                context.user_data.pop("admin_action", None)
                await update.message.reply_text(f"✅ Referral reward updated to ₹{money(amount)} per successful referral.", reply_markup=admin_kb()); return
    # Customer/reseller Android-ID input for API projects that require device binding.
    for _k in list(context.user_data.keys()):
        if not str(_k).startswith("awaiting_android_id_") or not context.user_data.get(_k):
            continue
        is_reseller_android = str(_k).startswith("awaiting_android_id_r_")
        plan_id=int(str(_k).split("_")[-1]); value=(update.message.text or "").strip()
        if len(value)<4 or len(value)>128 or any(ch.isspace() for ch in value):
            await update.message.reply_text("⚠️ Send a valid Android ID without spaces."); return
        context.user_data.pop(_k,None)
        context.user_data[f"android_id_r_{plan_id}" if is_reseller_android else f"android_id_{plan_id}"]=value
        row=reseller_plan_row(plan_id) if is_reseller_android else plan_row(plan_id)
        if row:
            kb = reseller_plan_kb(row["product_id"]) if is_reseller_android else customer_plan_kb(row["product_id"])
            await update.message.reply_text("✅ Android ID saved. Tap the plan again to continue.", reply_markup=kb)
        return

    # Customer custom wallet amount input. This runs before admin-only text handling.
    if context.user_data.get("awaiting_custom_amount"):
        value = (update.message.text or "").strip().replace(",", "")
        try:
            amount = int(value)
            if amount <= 0 or amount > 1000000:
                raise ValueError
        except ValueError:
            await update.message.reply_text("⚠️ Enter a valid whole amount between ₹1 and ₹10,00,000.")
            return

        context.user_data.pop("awaiting_custom_amount", None)
        u = update.effective_user
        ensure_user(u)
        try:
            gateway, order_id, payment_url = await asyncio.to_thread(
                create_payment_request, amount, u.id, "Custom Wallet Balance"
            )
            save_payment_order(order_id, u.id, amount, payment_url, purpose="balance", gateway=gateway)
            if gateway == "fampay":
                await update.message.reply_text(
                    f"💳 CUSTOM PAYMENT REQUEST\n\nAmount: ₹{amount}\nOrder ID: `{order_id}`\n\n👇 Scan the QR below to pay.",
                    parse_mode="Markdown",
                )
                await context.bot.send_photo(
                    chat_id=u.id,
                    photo=payment_url,
                    caption=f"📱 Scan to Pay\nCustom Amount: ₹{amount}\nOrder ID: {order_id}\nUPI: {payment_setting('fampay_upi_id','PAYMENT_UPI_ID',PAYMENT_UPI_ID)}",
                    reply_markup=InlineKeyboardMarkup([
                        [b("✔️ CHECK PAYMENT", f"verify:{order_id}", "success")],
                        [b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])],
                    ]),
                )
            else:
                await update.message.reply_text(
                    f"💳 CUSTOM PAYMENT REQUEST\n\nAmount: ₹{amount}\nOrder ID: `{order_id}`\n\n👇 Tap PAY NOW to complete the payment.",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("💳 PAY NOW", url=payment_url, style="success")],
                        [b("✔️ CHECK PAYMENT", f"verify:{order_id}", "success")],
                        [b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])],
                    ]),
                )
            context.application.create_task(
                verify_payment_loop(context.application, u.id, u.id, order_id, amount)
            )
        except Exception as exc:
            logging.exception("Custom amount QR generation failed")
            await update.message.reply_text(
                f"❌ PAYMENT QR ERROR\n\n{exc}",
                reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])]])
            )
        return

    if not is_admin(update.effective_user.id):
        return
    action = context.user_data.get("admin_action")
    if not action:
        return
    if action == 'raddprod':
        value=update.message.text.strip()
        if not value: await update.message.reply_text("⚠️ Product name cannot be empty."); return
        con=db(); con.execute("INSERT INTO reseller_products(name) VALUES(?)",(value,)); con.commit(); con.close(); context.user_data.pop('admin_action',None); await update.message.reply_text(f"✅ Reseller product added: {value}",reply_markup=admin_kb()); return
    if action == 'reditprod':
        value=update.message.text.strip(); pid=int(context.user_data['rproduct_id'])
        if not value: await update.message.reply_text("⚠️ Name cannot be empty."); return
        con=db(); con.execute("UPDATE reseller_products SET name=? WHERE id=?",(value,pid)); con.commit(); con.close(); context.user_data.pop('admin_action',None); await update.message.reply_text("✅ Reseller product renamed.",reply_markup=admin_kb()); return
    if action == 'raddplan_title':
        context.user_data['rplan_title']=update.message.text.strip(); context.user_data['admin_action']='raddplan_price'; await update.message.reply_text("💰 Send reseller price (number only):"); return
    if action == 'raddplan_price':
        try: price=int(update.message.text.strip()); assert price>=0
        except Exception: await update.message.reply_text("⚠️ Enter a valid price."); return
        pid=int(context.user_data['rproduct_id']); title=context.user_data['rplan_title']; con=db(); cur=con.execute("INSERT INTO reseller_plans(product_id,title,price,stock) VALUES(?,?,?,?)",(pid,title,price)); con.commit(); con.close(); context.user_data.clear(); await update.message.reply_text("✅ Reseller plan added. Now add keys from the plan's Add Key button.",reply_markup=admin_kb()); return
    if action == 'reditprice':
        try: price=int(update.message.text.strip()); assert price>=0
        except Exception: await update.message.reply_text("⚠️ Enter a valid price."); return
        pid=int(context.user_data['rplan_id']); con=db(); con.execute("UPDATE reseller_plans SET price=? WHERE id=?",(price,pid)); con.commit(); con.close(); context.user_data.pop('admin_action',None); await update.message.reply_text("✅ Reseller price updated.",reply_markup=admin_kb()); return
    if action == 'raddkey':
        key=update.message.text.strip(); pid=int(context.user_data['rplan_id'])
        if not key: await update.message.reply_text("⚠️ Key cannot be empty."); return
        con=db(); con.execute("INSERT INTO reseller_keys(plan_id,key_text,status) VALUES(?,?,'available')",(pid,key)); con.execute("UPDATE reseller_plans SET stock=(SELECT COUNT(*) FROM reseller_keys WHERE plan_id=? AND status='available') WHERE id=?",(pid,pid)); con.commit(); con.close(); context.user_data.pop('admin_action',None); await update.message.reply_text("✅ Reseller key added to stock.",reply_markup=admin_kb()); return

    value = update.message.text.strip()
    if not value:
        await update.message.reply_text("⚠️ Value cannot be empty. Try again.")
        return

    if action == "editcat":
        con = db()
        try:
            con.execute("UPDATE categories SET name=? WHERE id=?", (value, context.user_data["category_id"]))
            con.commit()
            msg = "✅ Category updated."
        except sqlite3.IntegrityError:
            msg = "⚠️ That category name already exists."
        finally:
            con.close()
        clear_admin_state(context)
        await update.message.reply_text(msg, reply_markup=admin_kb())
        return

    if action == "editprod":
        con = db()
        con.execute("UPDATE products SET name=? WHERE id=?", (value, context.user_data["product_id"]))
        con.commit()
        con.close()
        clear_admin_state(context)
        await update.message.reply_text("✅ Product updated.", reply_markup=admin_kb())
        return

    if action == "editplan_title":
        context.user_data["new_title"] = value
        context.user_data["admin_action"] = "editplan_price"
        await update.message.reply_text("💰 Send new price as a number.\nExample: 499")
        return

    if action == "editplan_price":
        try:
            price = int(value)
            if price < 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("⚠️ Enter a valid whole-number price.")
            return
        context.user_data["new_price"] = price
        context.user_data["admin_action"] = "editplan_stock"
        await update.message.reply_text("📦 Send new stock quantity.\nUse 0 for OUT OF STOCK / unlimited-style tracking.")
        return

    if action == "editplan_stock":
        try:
            stock = int(value)
            if stock < 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("⚠️ Enter a valid stock number.")
            return
        con = db()
        con.execute(
            "UPDATE plans SET title=?,price=?,stock=? WHERE id=?",
            (context.user_data["new_title"], context.user_data["new_price"], stock, context.user_data["plan_id"]),
        )
        con.commit()
        con.close()
        clear_admin_state(context)
        await update.message.reply_text("✅ Plan, price and stock updated.", reply_markup=admin_kb())
        return

    if action == "addcat":
        con = db()
        try:
            con.execute("INSERT INTO categories(name) VALUES(?)", (value,))
            con.commit()
            msg = f"✅ Category added: {value}"
        except sqlite3.IntegrityError:
            msg = "⚠️ That category already exists."
        finally:
            con.close()
        clear_admin_state(context)
        await update.message.reply_text(msg, reply_markup=admin_kb())
        return

    if action == "addprod":
        cat_id = context.user_data["category_id"]
        con = db()
        con.execute("INSERT INTO products(category_id,name) VALUES(?,?)", (cat_id, value))
        con.commit()
        con.close()
        clear_admin_state(context)
        await update.message.reply_text(f"✅ Product added: {value}", reply_markup=admin_kb())
        return

    if action == "addkey":
        plan_id = context.user_data["plan_id"]
        con = db()
        con.execute("INSERT INTO plan_keys(plan_id,key_text,status) VALUES(?,?,'available')", (plan_id, value))
        con.execute(
            "UPDATE plans SET stock=(SELECT COUNT(*) FROM plan_keys WHERE plan_id=? AND status='available') WHERE id=?",
            (plan_id, plan_id),
        )
        con.commit()
        con.close()
        clear_admin_state(context)
        await update.message.reply_text("✅ Key added to the plan stock.", reply_markup=admin_kb())
        return

    if action == "addplan_title":
        context.user_data["plan_title"] = value
        context.user_data["admin_action"] = "addplan_price"
        await update.message.reply_text("💰 Send price as a number.\nExample: 599")
        return

    if action == "addplan_price":
        try:
            price = int(value)
            if price < 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("⚠️ Enter only a valid whole-number price, e.g. 599.")
            return
        context.user_data["plan_price"] = price
        product_id = int(context.user_data["product_id"])
        row = product_row(product_id)
        if is_api_product(row):
            con = db()
            con.execute("INSERT INTO plans(product_id,title,price,stock) VALUES(?,?,?,0)", (product_id, context.user_data["plan_title"], price))
            con.commit(); con.close()
            title = context.user_data["plan_title"]
            clear_admin_state(context)
            await update.message.reply_text(f"✅ API plan added successfully.\n\n⏱️ {title}\n💰 ₹{price}\n📦 Stock: API-managed", reply_markup=admin_kb())
            return
        context.user_data["admin_action"] = "addplan_stock"
        await update.message.reply_text("📦 Send stock quantity.\nUse 0 if you want it shown as OUT OF STOCK.")
        return

    if action == "addplan_stock":
        try:
            stock = int(value)
            if stock < 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("⚠️ Enter a valid stock number, e.g. 10.")
            return
        con = db()
        con.execute(
            "INSERT INTO plans(product_id,title,price,stock) VALUES(?,?,?,?)",
            (context.user_data["product_id"], context.user_data["plan_title"], context.user_data["plan_price"], stock),
        )
        con.commit()
        con.close()
        clear_admin_state(context)
        await update.message.reply_text("✅ Plan added successfully.", reply_markup=admin_kb())
        return

    clear_admin_state(context)
    await update.message.reply_text("⚠️ Admin action expired. Open /admin again.", reply_markup=admin_kb())


async def process_referral(user, context):
    """Credit the configured referral reward once when a new user starts with a referral link."""
    if not context.args:
        return False
    payload = str(context.args[0]).strip()
    if not payload.lower().startswith("ref_"):
        return False
    try:
        referrer_id = int(payload.split("_", 1)[1])
    except (ValueError, IndexError):
        return False
    if referrer_id == user.id:
        return False

    con = db()
    try:
        con.execute("BEGIN IMMEDIATE")
        target = con.execute("SELECT referred_by FROM users WHERE user_id=?", (user.id,)).fetchone()
        referrer = con.execute("SELECT user_id FROM users WHERE user_id=?", (referrer_id,)).fetchone()
        if not target or not referrer or target["referred_by"] is not None:
            con.rollback()
            return False
        con.execute("UPDATE users SET referred_by=? WHERE user_id=?", (referrer_id, user.id))
        con.execute(
            "UPDATE users SET balance=ROUND(balance+?,2), updated_at=CURRENT_TIMESTAMP WHERE user_id=?",
            (referral_reward(), referrer_id),
        )
        con.commit()
        return True
    except Exception:
        con.rollback()
        logging.exception("Referral credit failed")
        return False
    finally:
        con.close()


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    if maintenance_enabled() and not is_admin(update.effective_user.id):
        await update.message.reply_text("🛠️ BOT UNDER MAINTENANCE\n\nService temporarily unavailable. Please try again later.")
        return
    if is_banned(update.effective_user.id) and not is_admin(update.effective_user.id):
        await update.message.reply_text("🚫 Your account is banned. Please contact admin.")
        return
    await process_referral(update.effective_user, context)
    text = home_text(update.effective_user.id)
    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=home_kb(update.effective_user.id)
    )
async def cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    try:
        await q.answer()
    except Exception:
        pass
    if is_banned(q.from_user.id) and not is_admin(q.from_user.id):
        await edit_current(q, "🚫 Your account is banned. Please contact admin.")
        return
    d = q.data or ""
    if maintenance_enabled() and not is_admin(q.from_user.id) and d not in ("noop",):
        await edit_current(q, "🛠️ BOT UNDER MAINTENANCE\n\nService temporarily unavailable. Please try again later.")
        return
    if d == "danger":
        await edit_current(q, "🛒 NARESH RESELLER STORE\n\nFast • Secure • Instant Delivery", reply_markup=home_kb(q.from_user.id))
        return


    if d == "adm" or d.startswith("adm:"):
        await admin_cb(update, context, d)
        return

    if d == "home":
        await edit_current(q, home_text(q.from_user.id), parse_mode="HTML", reply_markup=home_kb(q.from_user.id))
        return

    if d == "shop":
        await edit_current(q, f"{emoji_tag("store", "🛒")} PRODUCT STORE\n\nSelect a product:", parse_mode="HTML", reply_markup=customer_product_kb(None))
        return

    if d == "reseller_shop":
        if not is_reseller(q.from_user.id):
            await edit_current(q, "⛔ Reseller Store is only for approved resellers.", reply_markup=home_kb(q.from_user.id)); return
        await edit_current(q, "🏪 RESELLER STORE\n\nSelect a product:", reply_markup=reseller_kb())
        return

    if d.startswith("rshopprod:"):
        if not is_reseller(q.from_user.id):
            await edit_current(q, "⛔ Reseller Store is only for approved resellers.", reply_markup=home_kb(q.from_user.id)); return
        product_id=int(d.split(":",1)[1]); row=reseller_product_row(product_id)
        if not row or not row["active"]:
            await edit_current(q, "❌ Reseller product not found.", reply_markup=reseller_kb()); return
        await edit_current(q, f"📈 {row['name']}\n\n━━━━━━━━━━━━━━\n❗ Choose your package:", reply_markup=reseller_plan_kb(product_id)); return

    if d.startswith("rwalletbuy:"):
        if not is_reseller(q.from_user.id):
            await edit_current(q, "⛔ Reseller Store is only for approved resellers.", reply_markup=home_kb(q.from_user.id)); return
        plan_id=int(d.split(":",1)[1]); row=reseller_plan_row(plan_id)
        if not row or not row["active"]:
            await edit_current(q, "❌ Plan not found.", reply_markup=reseller_kb()); return
        amount=int(row["price"]); balance=get_balance(q.from_user.id)

        # All mapped reseller products use the live supplier API.
        if is_bala_reseller_plan(row):
            if balance<amount:
                await edit_current(q, f"❌ INSUFFICIENT BALANCE\n\n💰 Required: ₹{amount}\n💳 Your Balance: ₹{money(balance)}", reply_markup=InlineKeyboardMarkup([[b("💰 ADD BALANCE","balance","success")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return
            if not api_configured_for_product(row["product"]):
                await edit_current(q, "⚠️ Reseller API is not fully configured.\n\n💰 Your wallet was NOT charged.", reply_markup=InlineKeyboardMarkup([[b("🔄 TRY AGAIN",f"rwalletbuy:{plan_id}","primary")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return
            await edit_current(q, f"🛒 CONFIRM PURCHASE\n\n📦 {row['product']}\n⏱️ {row['title']}\n💰 Price: ₹{amount}\n💳 Wallet Balance: ₹{money(balance)}\n\nThe Reseller API will be checked first. Your wallet is charged only after a real key is returned.", reply_markup=InlineKeyboardMarkup([[b(f"✅ CONFIRM PURCHASE • ₹{amount}",f"rconfirmbuy:{plan_id}","success")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return

    if d.startswith("rconfirmbuy:"):
        if not is_reseller(q.from_user.id):
            await edit_current(q, "⛔ Reseller Store is only for approved resellers.", reply_markup=home_kb(q.from_user.id)); return
        plan_id=int(d.split(":",1)[1]); u=q.from_user; row=reseller_plan_row(plan_id)
        if not row or not row["active"]:
            await edit_current(q, "❌ Plan not found.", reply_markup=reseller_kb()); return

        # All mapped reseller products use the live supplier API.
        if is_bala_reseller_plan(row):
            amount=int(row["price"]); balance=get_balance(u.id)
            if balance < amount:
                await edit_current(q, f"❌ INSUFFICIENT BALANCE\n\n💰 Required: ₹{amount}\n💳 Your Balance: ₹{money(balance)}", reply_markup=InlineKeyboardMarkup([[b("💰 ADD BALANCE","balance","success")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return
            if not api_configured_for_product(row["product"]):
                await edit_current(q, "⚠️ Reseller API is not fully configured.\n\n💰 Your wallet was NOT charged.", reply_markup=InlineKeyboardMarkup([[b("🔄 TRY AGAIN",f"rwalletbuy:{plan_id}","primary")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return

            await edit_current(q, "⏳ CHECKING SUPPLIER SERVER...\n\nNo wallet deduction yet. Waiting for the API to return a real key.")
            android_id = str(context.user_data.pop(f"android_id_r_{plan_id}", "")).strip()
            try:
                key_text = await asyncio.to_thread(reseller_buy_api, row, u.id, android_id)
            except BalaServiceUnavailable:
                await edit_current(q, "🛠️ SUPPLIER SERVER UNAVAILABLE\n\n💰 Your wallet was NOT charged.", reply_markup=InlineKeyboardMarkup([[b("🔄 TRY AGAIN",f"rwalletbuy:{plan_id}","primary")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return
            except BalaPurchaseError as exc:
                await edit_current(q, f"❌ KEY GENERATION FAILED\n\n{str(exc)}\n\n💰 Your wallet was NOT charged.", reply_markup=InlineKeyboardMarkup([[b("🔄 TRY AGAIN",f"rwalletbuy:{plan_id}","primary")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return
            except Exception:
                logging.exception("Unexpected BALA reseller API error")
                await edit_current(q, "⚠️ KEY DELIVERY TEMPORARILY UNAVAILABLE\n\n💰 Your wallet was NOT charged.", reply_markup=InlineKeyboardMarkup([[b("🔄 TRY AGAIN",f"rwalletbuy:{plan_id}","primary")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return

            # The API returned a real key. Re-check the wallet inside a SQLite
            # transaction before charging, so a concurrent balance change cannot
            # silently create a negative balance.
            order_id=f"RSELL-{u.id}-{int(time.time())}-{secrets.token_hex(3)}"
            con=db()
            try:
                con.execute("BEGIN IMMEDIATE")
                wallet=con.execute("SELECT balance FROM users WHERE user_id=?",(u.id,)).fetchone()
                if not wallet or float(wallet["balance"]) < amount:
                    con.rollback()
                    logging.error("BALA key generated but reseller wallet became insufficient: user=%s plan=%s",u.id,plan_id)
                    await edit_current(q, "⚠️ Wallet balance changed while processing.\n\nPlease contact support before retrying so the generated key can be reconciled.", reply_markup=home_kb(u.id)); return
                con.execute("UPDATE users SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND balance>=?",(amount,u.id,amount))
                if con.execute("SELECT changes()").fetchone()[0] != 1:
                    con.rollback(); await edit_current(q, "⚠️ Balance changed. Try again.", reply_markup=reseller_plan_kb(row['product_id'])); return
                con.execute("INSERT INTO reseller_purchases(order_id,user_id,plan_id,amount,delivery_key,status) VALUES(?,?,?,?,?,?)",(order_id,u.id,plan_id,amount,key_text,'delivered'))
                con.commit()
            except Exception:
                con.rollback(); logging.exception("BALA reseller purchase save/debit failed")
                await edit_current(q, "⚠️ Purchase record could not be saved.\n\nPlease contact support before retrying.", reply_markup=home_kb(u.id)); return
            finally:
                con.close()
            await edit_current(q, f"✅ PURCHASE SUCCESSFUL\n\n📦 {row['product']}\n⏱️ {row['title']}\n💰 Paid from Wallet: ₹{amount}\n💳 Remaining Balance: ₹{money(get_balance(u.id))}\n\n🔑 YOUR KEY:\n{key_text}", reply_markup=InlineKeyboardMarkup([[copy_key_button(key_text)],[b("🛒 RESELLER STORE","reseller_shop","primary")],[b(f"{FALLBACK['back']} BACK","home","danger",EMOJI['back'])]])); return

        # ORIGINAL NON-BALA RESELLER FLOW — unchanged.
        stock=reseller_available_keys(plan_id); balance=get_balance(q.from_user.id); amount=int(row["price"])
        if stock<=0:
            await edit_current(q, "❌ OUT OF STOCK\n\nPlease try again later.", reply_markup=reseller_plan_kb(row["product_id"])); return
        if balance<amount:
            await edit_current(q, f"❌ INSUFFICIENT BALANCE\n\n💰 Required: ₹{amount}\n💳 Your Balance: ₹{money(balance)}", reply_markup=InlineKeyboardMarkup([[b("💰 ADD BALANCE","balance","success")],[b(f"{FALLBACK['back']} BACK",f"rshopprod:{row['product_id']}","danger",EMOJI['back'])]])); return
        con=db()
        try:
            con.execute("BEGIN IMMEDIATE")
            key=con.execute("SELECT * FROM reseller_keys WHERE plan_id=? AND status='available' ORDER BY id LIMIT 1",(plan_id,)).fetchone()
            wallet=con.execute("SELECT balance FROM users WHERE user_id=?",(u.id,)).fetchone()
            amount=int(row['price'])
            if not key or not wallet or float(wallet['balance'])<amount:
                con.rollback(); await edit_current(q, "❌ Key is currently unavailable or balance is insufficient.", reply_markup=reseller_plan_kb(row['product_id'])); return
            con.execute("UPDATE reseller_keys SET status='sold',assigned_user_id=?,assigned_at=CURRENT_TIMESTAMP WHERE id=? AND status='available'",(u.id,key['id']))
            if con.execute("SELECT changes()").fetchone()[0] != 1:
                con.rollback(); await edit_current(q, "❌ Key is no longer available. Try again.", reply_markup=reseller_plan_kb(row['product_id'])); return
            con.execute("UPDATE users SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND balance>=?",(amount,u.id,amount))
            if con.execute("SELECT changes()").fetchone()[0] != 1:
                con.rollback(); await edit_current(q, "❌ Balance changed. Try again.", reply_markup=reseller_plan_kb(row['product_id'])); return
            order_id=f"RSELL-{u.id}-{int(time.time())}-{secrets.token_hex(3)}"
            con.execute("INSERT INTO reseller_purchases(order_id,user_id,plan_id,amount,delivery_key,status) VALUES(?,?,?,?,?,?)",(order_id,u.id,plan_id,amount,key['key_text'],'delivered'))
            con.commit()
        except Exception:
            con.rollback(); logging.exception("Reseller purchase failed"); await edit_current(q, "⚠️ Purchase failed safely. No balance was charged.", reply_markup=reseller_plan_kb(row['product_id'])); return
        finally: con.close()
        await edit_current(q, f"✅ PURCHASE SUCCESSFUL\n\n📦 {row['product']}\n⏱️ {row['title']}\n💰 Paid from Wallet: ₹{amount}\n💳 Remaining Balance: ₹{money(get_balance(u.id))}\n\n🔑 YOUR KEY:\n{key['key_text']}", reply_markup=InlineKeyboardMarkup([[copy_key_button(key['key_text'])],[b("🛒 RESELLER STORE","reseller_shop","primary")],[b(f"{FALLBACK['back']} BACK","home","danger",EMOJI['back'])]])); return

    if d.startswith("shopcat:"):
        cat_id = int(d.split(":", 1)[1])
        name = category_name(cat_id)
        await edit_current(q, 
            f"📱 HACK STORE — {name}\n\n━━━━━━━━━━━━━━\n📌 Choose a product ❤️",
            reply_markup=customer_product_kb(cat_id),
        )
        return

    if d.startswith("shopprod:"):
        product_id = int(d.split(":", 1)[1])
        row = product_row(product_id)
        if not row:
            await edit_current(q, "❌ Product not found.", reply_markup=customer_category_kb())
            return
        await edit_current(q, 
            f"📈 {row['name']}\n\n━━━━━━━━━━━━━━\n❗ Choose your package from the list below:\n\n"
            f"⚠️ Type: {row['category']}\n🟢 Status: ONLINE ✅\n\n━━━━━━━━━━━━━━",
            reply_markup=customer_plan_kb(product_id),
        )
        return

    if d.startswith("walletbuy:"):
        plan_id = int(d.split(":", 1)[1])
        row = plan_row(plan_id)
        if not row:
            await edit_current(q, "❌ Plan not found.", reply_markup=customer_category_kb())
            return

        u = q.from_user
        ensure_user(u)
        balance = get_balance(u.id)
        amount = int(row["price"])

        if balance < amount:
            await edit_current(q, 
                f"❌ INSUFFICIENT BALANCE\n\n"
                f"💰 Required: ₹{amount}\n"
                f"💳 Your Balance: ₹{money(balance)}\n\n"
                "Please add balance first.",
                reply_markup=InlineKeyboardMarkup([
                    [b("💰 ADD BALANCE", "balance", "success")],
                    [b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])],
                ]),
            )
            return

        confirm_kb = InlineKeyboardMarkup([
            [b(f"✅ CONFIRM PURCHASE • ₹{amount}", f"confirmbuy:{plan_id}", "success")],
            [b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])],
        ])
        await edit_current(q, 
            f"🛒 CONFIRM PURCHASE\n\n"
            f"📦 {row['product']}\n"
            f"⏱️ {row['title']}\n"
            f"💰 Price: ₹{amount}\n"
            f"💳 Wallet Balance: ₹{money(balance)}\n\n"
            "The amount will be deducted only after confirmation.",
            reply_markup=confirm_kb,
        )
        return

    if d.startswith("confirmbuy:"):
        plan_id = int(d.split(":", 1)[1])
        row = plan_row(plan_id)
        if not row:
            await edit_current(q, "❌ Plan not found.", reply_markup=customer_category_kb())
            return

        u = q.from_user
        ensure_user(u)
        is_api = is_api_product(row)
        cfg = api_product_config(row["product"]) if is_api else None
        android_id = ""
        if cfg and cfg.get("require_android_id"):
            android_id = str(context.user_data.pop(f"android_id_{plan_id}", "")).strip()
            if not android_id:
                context.user_data[f"awaiting_android_id_{plan_id}"] = True
                await edit_current(q, f"📱 ANDROID ID REQUIRED\n\nProduct: {row['product']}\nPlan: {row['title']}\n\nSend the Android ID now.\nThis value will be sent only to the configured supplier API.", reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])]]) )
                return
        amount = int(row["price"])

        if not is_api_product(row):
            await edit_current(q, 
                "⚠️ Wallet purchase is enabled for API projects only.",
                reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])]])
            )
            return

        if not cfg or not api_configured_for_product(row["product"]):
            await edit_current(q, 
                "⚠️ Reseller API is not configured for this project.\n\nPlease contact admin. Your wallet was not charged.",
                reply_markup=InlineKeyboardMarkup([[b("🔄 TRY AGAIN", f"walletbuy:{plan_id}", "primary")], [b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])]]),
            )
            return

        # IMPORTANT: check the supplier purchase FIRST. We do not deduct wallet
        # balance before the live API can actually return a key.
        await edit_current(q, 
            "⏳ CHECKING SUPPLIER SERVER...\n\nPlease wait, your wallet will be charged only after a key is successfully generated.",
        )

        try:
            key_text = await asyncio.to_thread(reseller_buy_api, row, u.id, android_id)
        except BalaServiceUnavailable:
            await edit_current(q, 
                "🛠️ SUPPLIER SERVER UNDER MAINTENANCE\n\n"
                "Key delivery is temporarily unavailable.\n"
                "⏱️ Please try again after 10–15 minutes.\n\n"
                "💰 Your wallet was NOT charged.",
                reply_markup=InlineKeyboardMarkup([
                    [b("🔄 TRY AGAIN", f"walletbuy:{plan_id}", "primary")],
                    [b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])],
                ]),
            )
            return
        except BalaPurchaseError as exc:
            await edit_current(q, 
                f"❌ KEY GENERATION FAILED\n\n{str(exc)}\n\n💰 Your wallet was NOT charged.",
                reply_markup=InlineKeyboardMarkup([
                    [b("🔄 TRY AGAIN", f"walletbuy:{plan_id}", "primary")],
                    [b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])],
                ]),
            )
            return
        except Exception:
            logging.exception("Unexpected Reseller API error")
            await edit_current(q, 
                "⚠️ KEY DELIVERY TEMPORARILY UNAVAILABLE\n\n"
                "Please try again in 10–15 minutes.\n\n"
                "💰 Your wallet was NOT charged.",
                reply_markup=InlineKeyboardMarkup([
                    [b("🔄 TRY AGAIN", f"walletbuy:{plan_id}", "primary")],
                    [b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])],
                ]),
            )
            return

        # The supplier returned a real key. Only now debit the wallet and save
        # the purchase atomically. If balance is insufficient, do not silently
        # deliver a paid key.
        wallet_order_id = f"WALLET-{u.id}-{int(time.time())}-{secrets.token_hex(4)}"
        con = db()
        try:
            con.execute("BEGIN IMMEDIATE")
            wallet = con.execute("SELECT balance FROM users WHERE user_id=?", (u.id,)).fetchone()
            current = int(wallet["balance"]) if wallet else 0
            if current < amount:
                con.rollback()
                logging.error("BALA key generated but wallet became insufficient: user=%s plan=%s", u.id, plan_id)
                await edit_current(q, 
                    "⚠️ Your wallet balance changed while processing.\n\n"
                    "Please contact admin/support before using this key.",
                    reply_markup=home_kb(),
                )
                return

            con.execute(
                "UPDATE users SET balance=balance-?, updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND balance>=?",
                (amount, u.id, amount),
            )
            if con.execute("SELECT changes()").fetchone()[0] != 1:
                con.rollback()
                await edit_current(q, "❌ Balance changed. Please try again.", reply_markup=home_kb(q.from_user.id))
                return

            con.execute(
                """INSERT OR IGNORE INTO purchases
                   (order_id,user_id,plan_id,amount,key_id,delivery_key,delivery_source,status,delivered_at)
                   VALUES(?,?,?,?,NULL,?,?, 'delivered',CURRENT_TIMESTAMP)""",
                (wallet_order_id, u.id, plan_id, amount, key_text, "reseller_api"),
            )
            con.commit()
        except Exception:
            con.rollback()
            logging.exception("Wallet debit/purchase save failed after BALA key generation")
            await edit_current(q, 
                "⚠️ Purchase could not be finalized safely.\n\n"
                "Please contact admin/support immediately and do not retry repeatedly.",
                reply_markup=home_kb(),
            )
            return
        finally:
            con.close()

        new_balance = get_balance(u.id)
        await edit_current(q, 
            f"✅ PURCHASE SUCCESSFUL\n\n"
            f"📦 {row['product']}\n"
            f"⏱️ {row['title']}\n"
            f"💰 Paid from Wallet: ₹{amount}\n"
            f"💳 Remaining Balance: ₹{money(new_balance)}\n\n"
            f"🔑 YOUR KEY:\n{key_text}",
            reply_markup=InlineKeyboardMarkup([[copy_key_button(key_text)], [b("🛒 PRODUCT STORE","shop","primary")], [b(f"{FALLBACK['back']} BACK","home","danger",EMOJI["back"])]]),
        )
        return

    if d.startswith("buyplan:"):
        plan_id = int(d.split(":", 1)[1])
        row = plan_row(plan_id)
        if not row:
            await edit_current(q, "❌ Plan not found.", reply_markup=customer_category_kb())
            return
        is_api = is_api_product(row)
        # BALA is fulfilled live by the reseller API; never reject it for local stock.
        if not is_api_product(row) and (row["stock"] == 0 or available_key_count(plan_id) == 0):
            await edit_current(q, 
                f"❌ OUT OF STOCK\n\n{row['product']} — {row['title']}",
                reply_markup=customer_plan_kb(row["product_id"]),
            )
            return
        if is_api_product(row) and not api_configured_for_product(row["product"]):
            await edit_current(q, 
                "⚠️ Reseller API NOT CONFIGURED\n\nAdmin must configure this API project first.",
                reply_markup=customer_plan_kb(row["product_id"]),
            )
            return

        u = q.from_user
        ensure_user(u)
        android_id = ""
        cfg = api_product_config(row["product"]) if is_api else None
        if cfg and cfg.get("require_android_id"):
            android_id = str(context.user_data.pop(f"android_id_{plan_id}", "")).strip()
            if not android_id:
                context.user_data[f"awaiting_android_id_{plan_id}"] = True
                await edit_current(q, f"📱 ANDROID ID REQUIRED\n\nProduct: {row['product']}\nPlan: {row['title']}\n\nSend the Android ID now.", reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])]]))
                return
        amount = int(row["price"])
        try:
            gateway, order_id, payment_url = await asyncio.to_thread(
                create_payment_request, amount, u.id, f"{row['product']} - {row['title']}"
            )
            save_payment_order(order_id, u.id, amount, payment_url, purpose="plan", plan_id=plan_id, gateway=gateway, android_id=android_id)
            await edit_current(q, 
                f"💳 BUY PLAN PAYMENT\n\n"
                f"📦 Product: {row['product']}\n"
                f"💰 Plan: {row['title']}\n"
                f"Amount: ₹{amount}\nOrder ID: `{order_id}`\n"
                f"Gateway: {gateway.upper()}\n\n"
                "👇 Open the payment link below to pay.",
                parse_mode="Markdown",
            )
            if gateway == "fampay":
                await context.bot.send_photo(
                    chat_id=u.id,
                    photo=payment_url,
                    caption=f"📱 Scan to Pay\nProduct: {row['product']}\nPlan: {row['title']}\nAmount: ₹{amount}\nOrder ID: {order_id}",
                    reply_markup=InlineKeyboardMarkup([
                        [b("✔️ CHECK PAYMENT", f"verify:{order_id}", "success")],
                        [b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])],
                    ]),
                )
            else:
                await context.bot.send_message(
                    chat_id=u.id,
                    text=f"💳 CASHFREE PAYMENT LINK\n\nAmount: ₹{amount}\nOrder ID: {order_id}\n\nTap PAY NOW to complete the payment.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("💳 PAY NOW", url=payment_url, style="success")],
                        [b("✔️ CHECK PAYMENT", f"verify:{order_id}", "success")],
                        [b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])],
                    ]),
                )
            context.application.create_task(
                verify_payment_loop(context.application, u.id, u.id, order_id, amount)
            )
        except Exception as exc:
            logging.exception("Plan payment QR generation failed")
            await edit_current(q, 
                f"❌ PAYMENT QR ERROR\n\n{exc}",
                reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", f"shopprod:{row['product_id']}", "danger", EMOJI["back"])]])
            )
        return

    if d == "balance":
        balance_emoji = EMOJI["fire"]
        await edit_current(q, 
            f'{emoji_tag("fire", "💰")} <b>ADD BALANCE TO WALLET</b> {emoji_tag("fire", "💰")}\n\n'
            f'{emoji_tag("fire", "💵")} Add funds to your wallet quickly &amp; securely. {emoji_tag("fire", "🔒")}\n\n'
            f'{emoji_tag("fire", "👇")} Select an amount below or choose custom amount.',
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [b("₹100", "amount:100", "primary"), b("₹200", "amount:200", "primary")],
                [b("₹500", "amount:500", "primary"), b("₹1000", "amount:1000", "primary")],
                [b("✏️ TYPE CUSTOM AMOUNT", "custom_amount", "primary")],
                [b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])],
            ]),
        )
        return

    if d == "custom_amount":
        context.user_data["awaiting_custom_amount"] = True
        balance_emoji = EMOJI["fire"]
        await edit_current(q, 
            f'{emoji_tag("fire", "✏️")} <b>CUSTOM AMOUNT</b>\n\n'
            f'{emoji_tag("fire", "💰")} Send the amount you want to add to your wallet.\n'
            f'{emoji_tag("fire", "📝")} Example: 750',
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])]] )
        )
        return

    if d.startswith("amount:"):
        try:
            amount = int(d.split(":", 1)[1])
        except ValueError:
            await edit_current(q, "❌ Invalid amount.", reply_markup=home_kb(q.from_user.id))
            return

        u = q.from_user
        ensure_user(u)
        try:
            gateway, order_id, payment_url = await asyncio.to_thread(
                create_payment_request, amount, u.id, "Wallet Balance"
            )
            save_payment_order(order_id, u.id, amount, payment_url, gateway=gateway)
            await edit_current(q, 
                f"💳 PAYMENT REQUEST\n\nAmount: ₹{amount}\nOrder ID: `{order_id}`\nGateway: {gateway.upper()}\n\n"
                "👇 Open the payment link below to pay.",
                parse_mode="Markdown",
            )
            if gateway == "fampay":
                await context.bot.send_photo(
                    chat_id=u.id,
                    photo=payment_url,
                    caption=f"📱 Scan to Pay\nAmount: ₹{amount}\nOrder ID: {order_id}\nUPI: {payment_setting('fampay_upi_id','PAYMENT_UPI_ID',PAYMENT_UPI_ID)}",
                    reply_markup=InlineKeyboardMarkup([
                        [b("✔️ CHECK PAYMENT", f"verify:{order_id}", "success")],
                        [b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])],
                    ]),
                )
            else:
                await context.bot.send_message(
                    chat_id=u.id,
                    text=f"💳 CASHFREE PAYMENT LINK\n\nAmount: ₹{amount}\nOrder ID: {order_id}\n\nTap PAY NOW to complete the payment.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("💳 PAY NOW", url=payment_url, style="success")],
                        [b("✔️ CHECK PAYMENT", f"verify:{order_id}", "success")],
                        [b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])],
                    ]),
                )
            context.application.create_task(
                verify_payment_loop(context.application, u.id, u.id, order_id, amount)
            )
        except Exception as exc:
            logging.exception("FamPay QR generation failed")
            await edit_current(q, 
                f"❌ PAYMENT QR ERROR\n\n{exc}",
                reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])]])
            )
        return

    if d == "profile":
        u = q.from_user
        ensure_user(u)

        con = db()
        row = con.execute(
            "SELECT balance, username, full_name, created_at "
            "FROM users WHERE user_id=?",
            (u.id,)
        ).fetchone()

        spent_row = con.execute(
            "SELECT COALESCE(SUM(amount), 0) FROM purchases "
            "WHERE user_id=? AND status='success'",
            (u.id,)
        ).fetchone()

        keys_row = con.execute(
            "SELECT COUNT(*) FROM purchases "
            "WHERE user_id=? AND status='delivered' AND (key_id IS NOT NULL OR delivery_key IS NOT NULL)",
            (u.id,)
        ).fetchone()

        con.close()

        balance = row["balance"] if row else 0
        username = row["username"] if row else (u.username or "")
        full_name = row["full_name"] if row else (u.full_name or "")
        joined = row["created_at"] if row else ""

        if joined:
            joined = str(joined).split(" ")[0]
        else:
            joined = "N/A"

        spent = spent_row[0] if spent_row else 0
        keys = keys_row[0] if keys_row else 0

        profile_text = (
            "👤 USER PROFILE 👤\n\n"
            f"🧑‍💻 ID: {u.id}\n\n"
            f"👑 Name: {full_name}\n\n"
            f"🏅 Username: @{username.lstrip('@') if username else 'not set'}\n\n"
            f"⏰ Joined: {joined}\n\n"
            "━━━━━━━━━━━━━━━━━━\n"
            f"💰 Balance: ₹{money(balance)}\n"
            f"📊 Spent: ₹{spent}\n"
            f"🔑 Keys: {keys}\n\n"
            "👤 Profile photo fetched from Telegram. 🟢"
        )

        profile_kb = InlineKeyboardMarkup([
            [
                b(f"{FALLBACK['history']} All History", "history", "success", EMOJI["history"]),
                b("Add Balance", "balance", "success", EMOJI["add_balance"])
            ],
            [
                InlineKeyboardButton(
                    "🔙 Back",
                    callback_data="home"
                )
            ]
        ])

        try:
            photos = await context.bot.get_user_profile_photos(
                user_id=u.id,
                limit=1
            )

            if photos.total_count > 0:
                file_id = photos.photos[0][-1].file_id

                try:
                    await q.message.delete()
                except Exception:
                    pass

                await context.bot.send_photo(
                    chat_id=q.message.chat.id,
                    photo=file_id,
                    caption=profile_text,
                    reply_markup=profile_kb
                )
            else:
                await edit_current(q, 
                    profile_text,
                    reply_markup=profile_kb
                )

        except Exception:
            await edit_current(q, 
                profile_text,
                reply_markup=profile_kb
            )

        return

    if d == "history":
        u = q.from_user
        con = db()
        rows = con.execute(
            """SELECT pu.order_id, pu.amount, pu.delivery_key, pu.status, pu.delivered_at,
                      pl.title, p.name AS product
               FROM purchases pu
               JOIN plans pl ON pl.id=pu.plan_id
               JOIN products p ON p.id=pl.product_id
               WHERE pu.user_id=?
               ORDER BY pu.id DESC LIMIT 20""",
            (u.id,),
        ).fetchall()
        con.close()
        if not rows:
            text = "🔑 ALL HISTORY\n\nNo purchases found."
        else:
            parts = ["🔑 ALL HISTORY\n"]
            for r in rows:
                key = str(r["delivery_key"] or "—")
                parts.append(
                    f"📦 {r['product']} — {r['title']}\n"
                    f"💰 ₹{r['amount']} • {r['status']}\n"
                    f"🔑 {key}\n"
                    f"🕒 {r['delivered_at'] or 'Pending'}\n"
                    "━━━━━━━━━━━━━━"
                )
            text = "\n".join(parts)
        await edit_current(q, text, reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])]]) )
        return

    if d == "referral":
        u = q.from_user
        ensure_user(u)
        con = db()
        count = con.execute("SELECT COUNT(*) FROM users WHERE referred_by=?", (u.id,)).fetchone()[0]
        con.close()
        try:
            me = await context.bot.get_me()
            bot_username = me.username or ""
        except Exception:
            bot_username = ""
        link = f"https://t.me/{bot_username}?start=ref_{u.id}" if bot_username else "Referral link unavailable until bot username is set."
        reward = referral_reward()
        earned = count * reward
        share_url = urllib.parse.quote(link, safe="")
        await edit_current(q, 
            "👥 REFERRAL PROGRAM\n\n"
            f"💰 Reward: ₹{money(reward)} per successful referral\n"
            f"👥 Total Referrals: {count}\n"
            f"💵 Total Earned: ₹{earned:.2f}\n\n"
            f"🔗 Your Referral Link:\n{link}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📤 SHARE LINK", url=f"https://t.me/share/url?url={share_url}", style="success")],
                [b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])],
            ])
        )
        return

    if d == "support":
        tg_url = support_telegram_url()
        wa_url = support_whatsapp_url()
        buttons = []
        if tg_url:
            buttons.append([InlineKeyboardButton("💬 CHAT ON TELEGRAM", url=tg_url, style="success")])
        if wa_url:
            buttons.append([InlineKeyboardButton("📱 CHAT ON WHATSAPP", url=wa_url, style="success")])
        buttons.append([b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])])

        await edit_current(q, 
            "🧑‍💻 NEED HELP? WE'RE HERE TO HELP! 💚\n\n"
            "👉 If you have any questions, need assistance, "
            "or are facing any issues, contact our support team. 🎟️\n\n"
            "✅ Quick Responses\n"
            "✅ Issue Resolution\n"
            "✅ Friendly Assistance 💚\n\n"
            "📲 Choose your preferred support channel below.",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if d == "download":
        url = download_url()
        buttons = []
        if url:
            buttons.append([InlineKeyboardButton("📢 OPEN CHANNEL", url=url, style="success")])
        buttons.append([b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])])
        await edit_current(q, 
            "📥 DOWNLOAD APK\n\n📢 Download APK / Files from our official channel:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if d.startswith("verify:"):
        order_id = d.split(":", 1)[1].strip()
        try:
            con = db()
            order = con.execute("SELECT * FROM payment_orders WHERE order_id=?", (order_id,)).fetchone()
            con.close()
            if not order:
                await edit_current(q, "❌ Payment order not found.", reply_markup=home_kb(q.from_user.id))
                return
            gateway = str(order["gateway"] or "fampay").lower()
            result = await asyncio.to_thread(verify_gateway_payment, gateway, order_id)

            if order and order["purpose"] == "plan":
                delivered, key_text = await asyncio.to_thread(deliver_paid_plan, order_id, result)
                if delivered:
                    await edit_current(q, 
                        f"✅ PAYMENT VERIFIED & ORDER DELIVERED\n\n"
                        f"Order ID: {order_id}\nAmount: ₹{order['amount']}\n\n"
                        f"🔑 YOUR KEY:\n{key_text}",
                        reply_markup=home_kb(),
                    )
                elif str(result.get("status", "")).lower() == "success":
                    await edit_current(q, 
                        "⚠️ Payment verified, but automatic key delivery failed. Please contact admin.",
                        reply_markup=home_kb(),
                    )
                else:
                    await edit_current(q, 
                        f"⌛ PAYMENT NOT RECEIVED YET\n\nOrder ID: {order_id}\n\nAfter paying, tap Verify Payment again.",
                        reply_markup=InlineKeyboardMarkup([
                            [b("🔄 VERIFY PAYMENT", f"verify:{order_id}", "success")],
                            [b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])]
                        ]),
                    )
            else:
                paid, balance = credit_order_if_paid(order_id, result)
                if paid:
                    await edit_current(q, 
                        f"✅ PAYMENT VERIFIED\n\nOrder ID: {order_id}\n💰 New Balance: ₹{balance}",
                        reply_markup=home_kb(),
                    )
                else:
                    await edit_current(q, 
                        f"⌛ PAYMENT NOT RECEIVED YET\n\nOrder ID: {order_id}\n\nIf you have paid, wait a few seconds and tap Check Payment again.",
                        reply_markup=InlineKeyboardMarkup([
                            [b("🔄 CHECK PAYMENT", f"verify:{order_id}", "success")],
                            [b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])]
                        ]),
                    )
        except Exception as exc:
            await edit_current(q, 
                f"❌ VERIFY ERROR\n\n{exc}",
                reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "home", "danger", EMOJI["back"])]])
            )
        return

    if d == "verify":
        await edit_current(q, 
            "➕ VERIFY PAYMENT\n\nSelect an active payment QR first.",
            reply_markup=InlineKeyboardMarkup([[b(f"{FALLBACK['back']} BACK", "balance", "danger", EMOJI["back"])]])
        )
        return

    await q.answer("Unknown action", show_alert=True)


async def error_handler(update, context):
    err = context.error
    if isinstance(err, (TimedOut, NetworkError)):
        logging.warning("Telegram network timeout/error: %s", err)
        return
    logging.exception("Unhandled bot error", exc_info=err)


def main():
    raise SystemExit("This Cloudflare Worker is webhook-driven. Deploy with pywrangler/wrangler; do not run main().")


if __name__ == "__main__":
    main()
