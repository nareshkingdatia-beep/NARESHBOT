"""Small sqlite3-shaped compatibility layer backed by Cloudflare D1.

The uploaded bot uses synchronous sqlite3 calls. Cloudflare D1 is async, so this
adapter bridges D1 promises with Pyodide's run_sync and exposes the small subset
of sqlite3.Connection/Cursor behavior used by the bot.
"""
from pyodide.ffi import run_sync, to_py

_CURRENT_DB = None


def set_db(db):
    global _CURRENT_DB
    _CURRENT_DB = db


class Row(dict):
    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc

    def keys(self):
        return super().keys()


class Cursor:
    def __init__(self, rows=None, meta=None):
        self._rows = rows or []
        self._meta = meta or {}
        self.lastrowid = int(self._meta.get("last_row_id") or 0)
        self.rowcount = int(self._meta.get("changes") or 0)

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def fetchall(self):
        return list(self._rows)


class Connection:
    def __init__(self, env_db):
        self.env_db = env_db
        self.row_factory = None
        self._transaction = False
        self._pending = []

    def _result_to_py(self, result):
        try:
            result = to_py(result)
        except Exception:
            pass
        return result

    def execute(self, sql, params=()):
        sql = str(sql)
        upper = sql.strip().upper()
        if upper.startswith("BEGIN"):
            self._transaction = True
            self._pending = []
            return Cursor()
        if upper in ("COMMIT", "END"):
            if self._pending:
                statements = [self.env_db.prepare(q).bind(*p) if p else self.env_db.prepare(q) for q,p in self._pending]
                result = self._result_to_py(run_sync(self.env_db.batch(statements)))
                self._pending = []
                self._transaction = False
                return Cursor(meta={"changes": 0})
            self._transaction = False
            return Cursor()
        if upper.startswith("ROLLBACK"):
            self._pending = []
            self._transaction = False
            return Cursor()

        # DDL/DML/SELECT all use prepared statements. D1 auto-commits each
        # statement; transaction-heavy paths are handled by D1 batch where
        # possible, while preserving the bot's existing SQL interface.
        stmt = self.env_db.prepare(sql)
        if params:
            stmt = stmt.bind(*tuple(params))
        result = self._result_to_py(run_sync(stmt.run()))
        if not isinstance(result, dict):
            try:
                result = dict(result)
            except Exception:
                result = {}
        rows = result.get("results") or []
        converted=[]
        for row in rows:
            try: row = dict(row)
            except Exception: pass
            converted.append(Row(row))
        return Cursor(converted, result.get("meta") or {})

    def executemany(self, sql, seq):
        statements=[]
        for params in seq:
            stmt=self.env_db.prepare(sql).bind(*tuple(params))
            statements.append(stmt)
        if statements:
            run_sync(self.env_db.batch(statements))
        return Cursor(meta={"changes": len(statements)})

    def commit(self):
        return None

    def rollback(self):
        self._pending=[]
        self._transaction=False

    def close(self):
        return None


def db():
    if _CURRENT_DB is None:
        raise RuntimeError("D1 database binding is not initialized")
    return Connection(_CURRENT_DB)
