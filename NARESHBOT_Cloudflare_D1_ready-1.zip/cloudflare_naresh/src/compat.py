import asyncio, json
from types import SimpleNamespace
from urllib.parse import urlparse
from pyodide.ffi import run_sync

class TimedOut(Exception): pass
class NetworkError(Exception): pass

class InlineKeyboardButton:
    def __init__(self, text, callback_data=None, style=None, icon_custom_emoji_id=None, copy_text=None, url=None, **kw):
        self.text=text; self.callback_data=callback_data; self.style=style
        self.icon_custom_emoji_id=icon_custom_emoji_id; self.copy_text=copy_text; self.url=url

class CopyTextButton:
    def __init__(self, text): self.text=text

class InlineKeyboardMarkup:
    def __init__(self, inline_keyboard): self.inline_keyboard=inline_keyboard


def keyboard_json(markup):
    if markup is None: return None
    rows=[]
    for row in getattr(markup,'inline_keyboard',[]) or []:
        out=[]
        for b in row:
            item={'text':getattr(b,'text','')}
            if getattr(b,'callback_data',None) is not None: item['callback_data']=b.callback_data
            if getattr(b,'url',None): item['url']=b.url
            ce=getattr(b,'icon_custom_emoji_id',None)
            if ce: item['icon_custom_emoji_id']=ce
            cp=getattr(b,'copy_text',None)
            if cp: item['copy_text']={'text':cp.text}
            if getattr(b,'style',None): item['style']=b.style
            out.append(item)
        rows.append(out)
    return {'inline_keyboard':rows}

class Bot:
    def __init__(self, token, env): self.token=token; self.env=env
    async def api(self, method, payload=None):
        from js import fetch, Object
        payload=payload or {}
        opts=Object.fromEntries([("method","POST"),("headers",Object.fromEntries([("Content-Type","application/json")])),("body",json.dumps(payload))])
        resp=await fetch(f"https://api.telegram.org/bot{self.token}/{method}", opts)
        data=await resp.json()
        if not data.get('ok'):
            raise RuntimeError(data.get('description','Telegram API error'))
        return data.get('result')
    async def send_message(self, chat_id, text, reply_markup=None, parse_mode=None, **kw):
        p={'chat_id':chat_id,'text':text}
        if reply_markup: p['reply_markup']=keyboard_json(reply_markup)
        if parse_mode: p['parse_mode']=parse_mode
        return await self.api('sendMessage',p)
    async def send_photo(self, chat_id, photo, caption='', reply_markup=None, parse_mode=None, **kw):
        p={'chat_id':chat_id,'photo':photo,'caption':caption}
        if reply_markup: p['reply_markup']=keyboard_json(reply_markup)
        if parse_mode: p['parse_mode']=parse_mode
        return await self.api('sendPhoto',p)
    async def copy_message(self, chat_id, from_chat_id, message_id, **kw):
        return await self.api('copyMessage',{'chat_id':chat_id,'from_chat_id':from_chat_id,'message_id':message_id})
    async def get_me(self): return await self.api('getMe',{})
    async def get_custom_emoji_stickers(self, custom_emoji_ids):
        return await self.api('getCustomEmojiStickers',{'custom_emoji_ids':custom_emoji_ids})
    async def get_user_profile_photos(self, user_id, limit=1):
        return await self.api('getUserProfilePhotos',{'user_id':user_id,'limit':limit})
    async def delete_message(self, chat_id, message_id): return await self.api('deleteMessage',{'chat_id':chat_id,'message_id':message_id})

class Message:
    def __init__(self, bot, raw):
        self._bot=bot; self.raw=raw; self.message_id=raw.get('message_id'); self.chat=SimpleNamespace(id=raw.get('chat',{}).get('id'))
        self.text=raw.get('text','') or raw.get('caption','') or ''
        self.photo=raw.get('photo'); self.video=raw.get('video'); self.document=raw.get('document'); self.animation=raw.get('animation'); self.voice=raw.get('voice')
    async def reply_text(self,text,*args,reply_markup=None,parse_mode=None,**kw):
        return await self._bot.send_message(self.chat.id,text,reply_markup=reply_markup,parse_mode=parse_mode,**kw)
    async def delete(self): return await self._bot.delete_message(self.chat.id,self.message_id)

class User:
    def __init__(self, raw):
        self.id=int(raw.get('id')); self.username=raw.get('username','') or ''; self.full_name=((raw.get('first_name','')+' '+raw.get('last_name','')).strip() or raw.get('first_name',''))

class CallbackQuery:
    def __init__(self, bot, raw):
        self._bot=bot; self.raw=raw; self.id=raw.get('id'); self.data=raw.get('data',''); self.from_user=User(raw.get('from',{})); self.message=Message(bot,raw.get('message',{}))
    async def answer(self,text=None,show_alert=False,**kw):
        p={'callback_query_id':self.id}
        if text is not None: p['text']=text
        if show_alert: p['show_alert']=True
        return await self._bot.api('answerCallbackQuery',p)
    async def edit_message_text(self,text,*args,reply_markup=None,parse_mode=None,**kw):
        p={'chat_id':self.message.chat.id,'message_id':self.message.message_id,'text':text}
        if reply_markup: p['reply_markup']=keyboard_json(reply_markup)
        if parse_mode: p['parse_mode']=parse_mode
        return await self._bot.api('editMessageText',p)
    async def edit_message_caption(self,caption,*args,reply_markup=None,parse_mode=None,**kw):
        p={'chat_id':self.message.chat.id,'message_id':self.message.message_id,'caption':caption}
        if reply_markup: p['reply_markup']=keyboard_json(reply_markup)
        if parse_mode: p['parse_mode']=parse_mode
        return await self._bot.api('editMessageCaption',p)

class Update:
    ALL_TYPES=[]
    def __init__(self, bot, raw):
        self.raw=raw; self.message=Message(bot,raw['message']) if raw.get('message') else None
        self.callback_query=CallbackQuery(bot,raw['callback_query']) if raw.get('callback_query') else None
        if self.message: self.effective_user=User(raw['message'].get('from',{}))
        elif self.callback_query: self.effective_user=self.callback_query.from_user
        else: self.effective_user=None
    @classmethod
    def from_json(cls,bot,raw): return cls(bot,raw)

class Context:
    def __init__(self, bot, application, user_data, args=None, error=None):
        self.bot=bot; self.application=application; self.user_data=user_data; self.args=args or []; self.error=error

class ContextTypes:
    DEFAULT_TYPE=object

class Application:
    def __init__(self, bot): self.bot=bot; self.bot_data={}; self.env=bot.env
    def create_task(self,coro): return asyncio.create_task(coro)

class _Builder:
    def __init__(self): self.token=''; self.env=None
    def token(self,t): self.token=t; return self
    def build(self): return Application(Bot(self.token,self.env))
class DummyBuilder:
    @staticmethod
    def builder(): return _Builder()
Application.builder=staticmethod(DummyBuilder.builder)

class CommandHandler: 
    def __init__(self,*a,**kw): pass
class CallbackQueryHandler:
    def __init__(self,*a,**kw): pass
class MessageHandler:
    def __init__(self,*a,**kw): pass
class _Filter:
    def __and__(self,o): return self
    def __or__(self,o): return self
    def __invert__(self): return self
class filters:
    TEXT=_Filter(); COMMAND=_Filter(); PHOTO=_Filter(); VIDEO=_Filter(); VOICE=_Filter()
