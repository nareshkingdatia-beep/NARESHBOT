import json, logging
from workers import WorkerEntrypoint, Response
from compat import Bot, Update, Context
from d1sqlite import set_db
import nareshbot_logic as logic

logging.basicConfig(level=logging.INFO)

class Default(WorkerEntrypoint):
    async def fetch(self, request):
        # Bind D1 for the compatibility sqlite layer.
        set_db(self.env.DB)
        logic.BOT_TOKEN = getattr(self.env, 'BOT_TOKEN', '') or ''
        bot = Bot(logic.BOT_TOKEN, self.env)
        app = type('App', (), {})()
        app.bot = bot
        app.env = self.env
        app.bot_data = {}
        app.create_task = __import__('asyncio').create_task

        url = str(request.url)
        if request.method == 'GET':
            if '/health' in url:
                return Response.json({'ok': True, 'service': 'NARESHBOT Cloudflare Worker'})
            return Response('NARESHBOT Cloudflare Worker is online')

        if request.method != 'POST':
            return Response('Method Not Allowed', status=405)

        try:
            raw = await request.json()
        except Exception:
            return Response.json({'ok': False, 'error': 'Invalid JSON'}, status=400)

        if '/telegram/' not in url:
            return Response.json({'ok': True})

        update = Update.from_json(bot, raw)
        user = update.effective_user
        if not user:
            return Response.json({'ok': True})

        # Per-user conversation state is persisted in D1.
        row = await self.env.DB.prepare('SELECT data FROM user_sessions WHERE user_id=?').bind(user.id).first()
        user_data = {}
        if row and row.get('data'):
            try: user_data=json.loads(row['data'])
            except Exception: user_data={}
        ctx = Context(bot, app, user_data)

        try:
            if update.callback_query:
                await logic.cb(update, ctx)
            elif update.message:
                text=(update.message.text or '').strip()
                if text.startswith('/start'):
                    parts=text.split()[1:]
                    ctx.args=parts
                    await logic.start(update, ctx)
                elif text.startswith('/admin'):
                    ctx.args=text.split()[1:]
                    await logic.admin_panel(update, ctx)
                else:
                    await logic.admin_text(update, ctx)
        except Exception as exc:
            logging.exception('Webhook handler failed')
            return Response.json({'ok': False, 'error': str(exc)}, status=500)
        finally:
            await self.env.DB.prepare('INSERT INTO user_sessions(user_id,data,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET data=excluded.data,updated_at=CURRENT_TIMESTAMP').bind(user.id,json.dumps(ctx.user_data,separators=(',',':'))).run()

        return Response.json({'ok': True})
