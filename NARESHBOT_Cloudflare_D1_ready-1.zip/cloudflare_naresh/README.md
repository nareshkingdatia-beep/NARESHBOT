# NARESHBOT — Cloudflare Workers + D1

This project is a Cloudflare Workers webhook adaptation of the uploaded `NARESHBOT_auto_backup.py`.

## Important

The original bot uses `python-telegram-bot`, local SQLite, polling, synchronous `urllib`, and a local backup loop. Cloudflare Workers are request-driven and D1 is the persistent database. This package keeps the bot's existing business-logic module and supplies compatibility layers for Telegram objects and SQLite-style D1 access.

The uploaded Python file did **not** include your existing `naresh_store.db`, so this project cannot contain your existing users/balances/products/keys/history. The D1 database starts from the supplied schema. Export/import your existing SQLite database separately if you want existing records moved.

## Deploy

1. Install Node.js and `uv`.
2. Install Wrangler/Python Worker tooling:
   `uvx --from workers-py pywrangler init`
3. Create the D1 database:
   `npx wrangler d1 create nareshbot-db`
4. Put the returned database ID into `wrangler.toml`.
5. Initialize the remote D1 database:
   `npx wrangler d1 execute nareshbot-db --remote --file=./schema.sql`
6. Set the bot token as a Worker secret:
   `npx wrangler secret put BOT_TOKEN`
7. Deploy:
   `uv run pywrangler deploy`
8. Set the Telegram webhook to:
   `https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev/telegram/CHANGE_THIS_SECRET`

Use any long random value for `CHANGE_THIS_SECRET`. The Worker only accepts Telegram POSTs on a URL containing `/telegram/`.

## Test

Open the Worker URL in a browser. `/health` should return JSON with `ok: true`.

## D1 persistence / backups

D1 is the persistent store; the old local `naresh_store.db` backup loop is intentionally not used. Cloudflare D1 provides managed recovery/time-travel features, and longer-term exports can be stored in R2/Workflows if desired.
